﻿namespace handelskalkulation
{
    partial class frm_handelskalkulation
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_nettolisteneinkaufspreis = new System.Windows.Forms.TextBox();
            this.lbl_nettolisteneinkaufspreis = new System.Windows.Forms.Label();
            this.lbl_lieferantenrabattsatz = new System.Windows.Forms.Label();
            this.tb_lieferantenrabattsatz = new System.Windows.Forms.TextBox();
            this.lbl_lieferantenrabatt = new System.Windows.Forms.Label();
            this.lbl_zieleinkaufspreis = new System.Windows.Forms.Label();
            this.gb_zieleinkaufspreis = new System.Windows.Forms.GroupBox();
            this.tb_lieferantenrabatt = new System.Windows.Forms.TextBox();
            this.tb_zieleinkaufspreis = new System.Windows.Forms.TextBox();
            this.lbl_vh_0 = new System.Windows.Forms.Label();
            this.btn_vorwaertskalkulation = new System.Windows.Forms.Button();
            this.gb_bareinkaufspreis = new System.Windows.Forms.GroupBox();
            this.tb_lieferskonto = new System.Windows.Forms.TextBox();
            this.tb_zieleinkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_lieferskontosatz = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_lieferskontosatz = new System.Windows.Forms.Label();
            this.lbl_bareinkaufspreis = new System.Windows.Forms.Label();
            this.tb_bareinkaufspreis = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gb_einstandspreis = new System.Windows.Forms.GroupBox();
            this.lbl_absolut = new System.Windows.Forms.Label();
            this.tb_bareinkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_bezugskosten = new System.Windows.Forms.TextBox();
            this.lbl_bareinkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_bezugskosten = new System.Windows.Forms.Label();
            this.lbl_einstandspreis = new System.Windows.Forms.Label();
            this.tb_einstandspreis = new System.Windows.Forms.TextBox();
            this.gb_barverkaufspreis = new System.Windows.Forms.GroupBox();
            this.tb_gewinn = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_selbstkostenpreis_2 = new System.Windows.Forms.TextBox();
            this.tb_gewinnsatz = new System.Windows.Forms.TextBox();
            this.lbl_gewinn = new System.Windows.Forms.Label();
            this.lbl_selbstkostenpreis_2 = new System.Windows.Forms.Label();
            this.lbl_gewinnsatz = new System.Windows.Forms.Label();
            this.lbl_barverkaufspreis = new System.Windows.Forms.Label();
            this.tb_barverkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_selbstkostenpreis = new System.Windows.Forms.GroupBox();
            this.tb_handlungskosten = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_einstandspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_handlungskostensatz = new System.Windows.Forms.TextBox();
            this.lbl_handlungskosten = new System.Windows.Forms.Label();
            this.lbl_einstandspreis_2 = new System.Windows.Forms.Label();
            this.lbl_handlungskostensatz = new System.Windows.Forms.Label();
            this.lbl_selbstkostenpreis = new System.Windows.Forms.Label();
            this.tb_selbstkostenpreis = new System.Windows.Forms.TextBox();
            this.gb_zielverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tb_kundenskonto = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_barverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_kundenskontosatz = new System.Windows.Forms.TextBox();
            this.lbl_kundenskonto = new System.Windows.Forms.Label();
            this.lbl_barverkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_kundenskontosatz = new System.Windows.Forms.Label();
            this.lbl_zielverkaufspreis = new System.Windows.Forms.Label();
            this.tb_zielverkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_nettolistenverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.tb_kundenrabatt = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tb_zielverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_kundenrabattsatz = new System.Windows.Forms.TextBox();
            this.lbl_kundenrabatt = new System.Windows.Forms.Label();
            this.lbl_zielverkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_kundenrabattsatz = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tb_nettolistenverkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_bruttoverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.tb_umsatzsteuer = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tb_nettolistenverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_umsatzsteuersatz = new System.Windows.Forms.TextBox();
            this.lbl_umsatzsteuer = new System.Windows.Forms.Label();
            this.lbl_nettolistenverkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_umsatzsteuersatz = new System.Windows.Forms.Label();
            this.lbl_bruttoverkaufspreis = new System.Windows.Forms.Label();
            this.tb_bruttoverkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_r_nettolistenverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.tb_r_umsatzsteuer = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tb_r_nettolistenverkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_r_umsatzsteuersatz = new System.Windows.Forms.TextBox();
            this.lbl_r_umsatzsteuer = new System.Windows.Forms.Label();
            this.lbl_r_nettolistenverkaufspreis = new System.Windows.Forms.Label();
            this.lbl_r_umsatzsteuersatz = new System.Windows.Forms.Label();
            this.lbl_r_bruttoverkaufspreis = new System.Windows.Forms.Label();
            this.tb_r_bruttoverkaufspreis = new System.Windows.Forms.TextBox();
            this.btn_rueckwaertskalkulation = new System.Windows.Forms.Button();
            this.gb_r_zielverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.tb_r_kundenrabatt = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tb_r_zielverkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_r_kundenrabattsatz = new System.Windows.Forms.TextBox();
            this.lbl_r_kundenrabatt = new System.Windows.Forms.Label();
            this.lbl_r_zielverkaufspreis = new System.Windows.Forms.Label();
            this.lbl_r_kundenrabattsatz = new System.Windows.Forms.Label();
            this.lbl_r_nettolistenverkaufspreis_2 = new System.Windows.Forms.Label();
            this.tb_r_nettolistenverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.gb_r_barverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.tb_r_kundenskonto = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.tb_r_barverkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_r_kundenskontosatz = new System.Windows.Forms.TextBox();
            this.lbl_r_kundenskonto = new System.Windows.Forms.Label();
            this.lbl_r_barverkaufspreis = new System.Windows.Forms.Label();
            this.lbl_r_kundenskontosatz = new System.Windows.Forms.Label();
            this.lbl_r_zielverkaufspreis_2 = new System.Windows.Forms.Label();
            this.tb_r_zielverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.gb_r_selbstkostenpreis = new System.Windows.Forms.GroupBox();
            this.tb_r_gewinn = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.tb_r_barverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_r_gewinnsatz = new System.Windows.Forms.TextBox();
            this.lbl_r_gewinn = new System.Windows.Forms.Label();
            this.lbl_r_selbstkostenpreis = new System.Windows.Forms.Label();
            this.lbl_r_gewinnsatz = new System.Windows.Forms.Label();
            this.lbl_r_barverkaufspreis_2 = new System.Windows.Forms.Label();
            this.tb_r_selbstkostenpreis = new System.Windows.Forms.TextBox();
            this.gb_r_einstandspreis = new System.Windows.Forms.GroupBox();
            this.tb_r_handlungskosten = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tb_r_selbstkostenpreis_2 = new System.Windows.Forms.TextBox();
            this.tb_r_handlungskostensatz = new System.Windows.Forms.TextBox();
            this.lbl_r_handlungskosten = new System.Windows.Forms.Label();
            this.lbl_r_selbstkostenpreis_2 = new System.Windows.Forms.Label();
            this.lbl_r_einstandspreis = new System.Windows.Forms.Label();
            this.lbl_r_handlungskostensatz = new System.Windows.Forms.Label();
            this.tb_r_einstandspreis = new System.Windows.Forms.TextBox();
            this.gb_r_bareinkaufspreis = new System.Windows.Forms.GroupBox();
            this.label45 = new System.Windows.Forms.Label();
            this.tb_r_einstandspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_r_bezugskosten = new System.Windows.Forms.TextBox();
            this.lbl_r_einstandspreis_2 = new System.Windows.Forms.Label();
            this.lbl_r_bareinkaufspreis = new System.Windows.Forms.Label();
            this.lbl_r_bezugskosten = new System.Windows.Forms.Label();
            this.tb_r_bareinkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_r_zieleinkaufspreis = new System.Windows.Forms.GroupBox();
            this.label46 = new System.Windows.Forms.Label();
            this.tb_r_lieferskonto = new System.Windows.Forms.TextBox();
            this.tb_r_bareinkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_r_lieferskontosatz = new System.Windows.Forms.TextBox();
            this.lbl_r_lieferskonto = new System.Windows.Forms.Label();
            this.lbl_r_bareinkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_r_zieleinkaufspreis = new System.Windows.Forms.Label();
            this.lbl_r_lieferskontosatz = new System.Windows.Forms.Label();
            this.tb_r_zieleinkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_r_nettolisteneinkaufspreis = new System.Windows.Forms.GroupBox();
            this.label47 = new System.Windows.Forms.Label();
            this.tb_r_lieferantenrabatt = new System.Windows.Forms.TextBox();
            this.tb_r_zieleinkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_r_lieferantenrabattsatz = new System.Windows.Forms.TextBox();
            this.lbl_r_lieferantenrabatt = new System.Windows.Forms.Label();
            this.lbl_r_nettolisteneinkaufspreis = new System.Windows.Forms.Label();
            this.lbl_r_lieferantenrabattsatz = new System.Windows.Forms.Label();
            this.lbl_r_zieleinkaufspreis_2 = new System.Windows.Forms.Label();
            this.tb_r_nettolisteneinkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_d_zieleinkaufspreis = new System.Windows.Forms.GroupBox();
            this.label48 = new System.Windows.Forms.Label();
            this.tb_d_lieferantenrabatt = new System.Windows.Forms.TextBox();
            this.tb_d_nettolisteneinkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_d_lieferantenrabattsatz = new System.Windows.Forms.TextBox();
            this.lbl_d_lieferantenrabatt = new System.Windows.Forms.Label();
            this.lbl_d_nettolisteneinkaufspreis = new System.Windows.Forms.Label();
            this.lbl_d_lieferantenrabattsatz = new System.Windows.Forms.Label();
            this.lbl_d_zieleinkaufspreis = new System.Windows.Forms.Label();
            this.tb_d_zieleinkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_d_bareinkaufspreis = new System.Windows.Forms.GroupBox();
            this.label49 = new System.Windows.Forms.Label();
            this.tb_d_lieferskonto = new System.Windows.Forms.TextBox();
            this.tb_d_zieleinkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_d_lieferskontosatz = new System.Windows.Forms.TextBox();
            this.lbl_d_lieferskonto = new System.Windows.Forms.Label();
            this.lbl_d_zieleinkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_d_lieferskontosatz = new System.Windows.Forms.Label();
            this.lbl_d_bareinkaufspreis = new System.Windows.Forms.Label();
            this.tb_d_bareinkaufspreis = new System.Windows.Forms.TextBox();
            this.gb_d_einstandspreis = new System.Windows.Forms.GroupBox();
            this.label56 = new System.Windows.Forms.Label();
            this.tb_d_bareinkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_d_bezugskosten = new System.Windows.Forms.TextBox();
            this.lbl_d_bareinkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_d_bezugskosten = new System.Windows.Forms.Label();
            this.lbl_d_einstandspreis = new System.Windows.Forms.Label();
            this.tb_d_einstandspreis = new System.Windows.Forms.TextBox();
            this.gb_d_selbstkostenpreis = new System.Windows.Forms.GroupBox();
            this.tb_d_handlungskosten = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.tb_d_einstandspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_d_handlungskostensatz = new System.Windows.Forms.TextBox();
            this.lbl_d_handlungskosten = new System.Windows.Forms.Label();
            this.lbl_d_einstandspreis_2 = new System.Windows.Forms.Label();
            this.lbl_d_handlungskostensatz = new System.Windows.Forms.Label();
            this.lbl_d_selbstkostenpreis = new System.Windows.Forms.Label();
            this.tb_d_selbstkostenpreis = new System.Windows.Forms.TextBox();
            this.gb_gewinn = new System.Windows.Forms.GroupBox();
            this.tb_d_gewinnsatz = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.tb_d_barverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.tb_d_selbstkostenpreis_2 = new System.Windows.Forms.TextBox();
            this.lbl_d_selbstkostenpreis_2 = new System.Windows.Forms.Label();
            this.lbl_d_barverkaufspreis_2 = new System.Windows.Forms.Label();
            this.lbl_d_gewinnsatz = new System.Windows.Forms.Label();
            this.lbl_d_gewinn = new System.Windows.Forms.Label();
            this.tb_d_gewinn = new System.Windows.Forms.TextBox();
            this.gb_d_barverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.tb_d_kundenskonto = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.tb_d_barverkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_d_kundenskontosatz = new System.Windows.Forms.TextBox();
            this.lbl_d_kundenskonto = new System.Windows.Forms.Label();
            this.lbl_d_barverkaufspreis = new System.Windows.Forms.Label();
            this.lbl_d_kundenskontosatz = new System.Windows.Forms.Label();
            this.lbl_d_zielverkaufspreis_2 = new System.Windows.Forms.Label();
            this.tb_d_zielverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.gb_d_zielverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.tb_d_kundenrabatt = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.tb_d_zielverkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_d_kundenrabattsatz = new System.Windows.Forms.TextBox();
            this.lbl_d_kundenrabatt = new System.Windows.Forms.Label();
            this.lbl_d_zielverkaufspreis = new System.Windows.Forms.Label();
            this.lbl_d_kundenrabattsatz = new System.Windows.Forms.Label();
            this.lbl_d_nettolistenverkaufspreis_2 = new System.Windows.Forms.Label();
            this.tb_d_nettolistenverkaufspreis_2 = new System.Windows.Forms.TextBox();
            this.gb_d_nettolistenverkaufspreis = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.tb_d_umsatzsteuer = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.tb_d_nettolistenverkaufspreis = new System.Windows.Forms.TextBox();
            this.tb_d_umsatzsteuersatz = new System.Windows.Forms.TextBox();
            this.lbl_d_umsatzsteuer = new System.Windows.Forms.Label();
            this.lbl_d_nettolistenverkaufspreis = new System.Windows.Forms.Label();
            this.lbl_d_umsatzsteuersatz = new System.Windows.Forms.Label();
            this.lbl_d_bruttoverkaufspreis = new System.Windows.Forms.Label();
            this.tb_d_bruttoverkaufspreis = new System.Windows.Forms.TextBox();
            this.btn_differenzkalkulation = new System.Windows.Forms.Button();
            this.gb_zieleinkaufspreis.SuspendLayout();
            this.gb_bareinkaufspreis.SuspendLayout();
            this.gb_einstandspreis.SuspendLayout();
            this.gb_barverkaufspreis.SuspendLayout();
            this.gb_selbstkostenpreis.SuspendLayout();
            this.gb_zielverkaufspreis.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gb_nettolistenverkaufspreis.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.gb_bruttoverkaufspreis.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.gb_r_nettolistenverkaufspreis.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.gb_r_zielverkaufspreis.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.gb_r_barverkaufspreis.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.gb_r_selbstkostenpreis.SuspendLayout();
            this.gb_r_einstandspreis.SuspendLayout();
            this.gb_r_bareinkaufspreis.SuspendLayout();
            this.gb_r_zieleinkaufspreis.SuspendLayout();
            this.gb_r_nettolisteneinkaufspreis.SuspendLayout();
            this.gb_d_zieleinkaufspreis.SuspendLayout();
            this.gb_d_bareinkaufspreis.SuspendLayout();
            this.gb_d_einstandspreis.SuspendLayout();
            this.gb_d_selbstkostenpreis.SuspendLayout();
            this.gb_gewinn.SuspendLayout();
            this.gb_d_barverkaufspreis.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.gb_d_zielverkaufspreis.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.gb_d_nettolistenverkaufspreis.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_nettolisteneinkaufspreis
            // 
            this.tb_nettolisteneinkaufspreis.Location = new System.Drawing.Point(160, 20);
            this.tb_nettolisteneinkaufspreis.Name = "tb_nettolisteneinkaufspreis";
            this.tb_nettolisteneinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_nettolisteneinkaufspreis.TabIndex = 1;
            this.tb_nettolisteneinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_nettolisteneinkaufspreis
            // 
            this.lbl_nettolisteneinkaufspreis.AutoSize = true;
            this.lbl_nettolisteneinkaufspreis.Location = new System.Drawing.Point(20, 20);
            this.lbl_nettolisteneinkaufspreis.Name = "lbl_nettolisteneinkaufspreis";
            this.lbl_nettolisteneinkaufspreis.Size = new System.Drawing.Size(119, 13);
            this.lbl_nettolisteneinkaufspreis.TabIndex = 2;
            this.lbl_nettolisteneinkaufspreis.Text = "Nettolisteneinkaufspreis";
            // 
            // lbl_lieferantenrabattsatz
            // 
            this.lbl_lieferantenrabattsatz.AutoSize = true;
            this.lbl_lieferantenrabattsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_lieferantenrabattsatz.Name = "lbl_lieferantenrabattsatz";
            this.lbl_lieferantenrabattsatz.Size = new System.Drawing.Size(106, 13);
            this.lbl_lieferantenrabattsatz.TabIndex = 3;
            this.lbl_lieferantenrabattsatz.Text = "Lieferantenrabattsatz";
            // 
            // tb_lieferantenrabattsatz
            // 
            this.tb_lieferantenrabattsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_lieferantenrabattsatz.Name = "tb_lieferantenrabattsatz";
            this.tb_lieferantenrabattsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_lieferantenrabattsatz.TabIndex = 4;
            this.tb_lieferantenrabattsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_lieferantenrabatt
            // 
            this.lbl_lieferantenrabatt.AutoSize = true;
            this.lbl_lieferantenrabatt.Location = new System.Drawing.Point(20, 60);
            this.lbl_lieferantenrabatt.Name = "lbl_lieferantenrabatt";
            this.lbl_lieferantenrabatt.Size = new System.Drawing.Size(93, 13);
            this.lbl_lieferantenrabatt.TabIndex = 5;
            this.lbl_lieferantenrabatt.Text = "- Lieferantenrabatt";
            // 
            // lbl_zieleinkaufspreis
            // 
            this.lbl_zieleinkaufspreis.AutoSize = true;
            this.lbl_zieleinkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_zieleinkaufspreis.Name = "lbl_zieleinkaufspreis";
            this.lbl_zieleinkaufspreis.Size = new System.Drawing.Size(95, 13);
            this.lbl_zieleinkaufspreis.TabIndex = 6;
            this.lbl_zieleinkaufspreis.Text = "= Zieleinkaufspreis";
            // 
            // gb_zieleinkaufspreis
            // 
            this.gb_zieleinkaufspreis.Controls.Add(this.tb_lieferantenrabatt);
            this.gb_zieleinkaufspreis.Controls.Add(this.tb_nettolisteneinkaufspreis);
            this.gb_zieleinkaufspreis.Controls.Add(this.tb_lieferantenrabattsatz);
            this.gb_zieleinkaufspreis.Controls.Add(this.lbl_lieferantenrabatt);
            this.gb_zieleinkaufspreis.Controls.Add(this.lbl_nettolisteneinkaufspreis);
            this.gb_zieleinkaufspreis.Controls.Add(this.lbl_lieferantenrabattsatz);
            this.gb_zieleinkaufspreis.Controls.Add(this.lbl_zieleinkaufspreis);
            this.gb_zieleinkaufspreis.Controls.Add(this.tb_zieleinkaufspreis);
            this.gb_zieleinkaufspreis.Controls.Add(this.lbl_vh_0);
            this.gb_zieleinkaufspreis.Location = new System.Drawing.Point(0, 0);
            this.gb_zieleinkaufspreis.Name = "gb_zieleinkaufspreis";
            this.gb_zieleinkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_zieleinkaufspreis.TabIndex = 7;
            this.gb_zieleinkaufspreis.TabStop = false;
            this.gb_zieleinkaufspreis.Text = "Zieleinkaufspreis";
            // 
            // tb_lieferantenrabatt
            // 
            this.tb_lieferantenrabatt.Enabled = false;
            this.tb_lieferantenrabatt.Location = new System.Drawing.Point(220, 60);
            this.tb_lieferantenrabatt.Name = "tb_lieferantenrabatt";
            this.tb_lieferantenrabatt.Size = new System.Drawing.Size(40, 20);
            this.tb_lieferantenrabatt.TabIndex = 10;
            this.tb_lieferantenrabatt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_zieleinkaufspreis
            // 
            this.tb_zieleinkaufspreis.Enabled = false;
            this.tb_zieleinkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_zieleinkaufspreis.Name = "tb_zieleinkaufspreis";
            this.tb_zieleinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_zieleinkaufspreis.TabIndex = 8;
            this.tb_zieleinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_vh_0
            // 
            this.lbl_vh_0.AutoSize = true;
            this.lbl_vh_0.Location = new System.Drawing.Point(280, 20);
            this.lbl_vh_0.Name = "lbl_vh_0";
            this.lbl_vh_0.Size = new System.Drawing.Size(66, 13);
            this.lbl_vh_0.TabIndex = 9;
            this.lbl_vh_0.Text = "von Hundert";
            // 
            // btn_vorwaertskalkulation
            // 
            this.btn_vorwaertskalkulation.Location = new System.Drawing.Point(100, 960);
            this.btn_vorwaertskalkulation.Name = "btn_vorwaertskalkulation";
            this.btn_vorwaertskalkulation.Size = new System.Drawing.Size(160, 23);
            this.btn_vorwaertskalkulation.TabIndex = 8;
            this.btn_vorwaertskalkulation.Text = "Berechne Vorwärts";
            this.btn_vorwaertskalkulation.UseVisualStyleBackColor = true;
            this.btn_vorwaertskalkulation.Click += new System.EventHandler(this.btn_vorwaertskalkulation_Click);
            // 
            // gb_bareinkaufspreis
            // 
            this.gb_bareinkaufspreis.Controls.Add(this.tb_lieferskonto);
            this.gb_bareinkaufspreis.Controls.Add(this.tb_zieleinkaufspreis_2);
            this.gb_bareinkaufspreis.Controls.Add(this.tb_lieferskontosatz);
            this.gb_bareinkaufspreis.Controls.Add(this.label2);
            this.gb_bareinkaufspreis.Controls.Add(this.label3);
            this.gb_bareinkaufspreis.Controls.Add(this.lbl_lieferskontosatz);
            this.gb_bareinkaufspreis.Controls.Add(this.lbl_bareinkaufspreis);
            this.gb_bareinkaufspreis.Controls.Add(this.tb_bareinkaufspreis);
            this.gb_bareinkaufspreis.Controls.Add(this.label6);
            this.gb_bareinkaufspreis.Location = new System.Drawing.Point(0, 120);
            this.gb_bareinkaufspreis.Name = "gb_bareinkaufspreis";
            this.gb_bareinkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_bareinkaufspreis.TabIndex = 9;
            this.gb_bareinkaufspreis.TabStop = false;
            this.gb_bareinkaufspreis.Text = "Bareinkaufspreis";
            // 
            // tb_lieferskonto
            // 
            this.tb_lieferskonto.Enabled = false;
            this.tb_lieferskonto.Location = new System.Drawing.Point(220, 60);
            this.tb_lieferskonto.Name = "tb_lieferskonto";
            this.tb_lieferskonto.Size = new System.Drawing.Size(40, 20);
            this.tb_lieferskonto.TabIndex = 11;
            this.tb_lieferskonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_zieleinkaufspreis_2
            // 
            this.tb_zieleinkaufspreis_2.Enabled = false;
            this.tb_zieleinkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_zieleinkaufspreis_2.Name = "tb_zieleinkaufspreis_2";
            this.tb_zieleinkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_zieleinkaufspreis_2.TabIndex = 1;
            this.tb_zieleinkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_lieferskontosatz
            // 
            this.tb_lieferskontosatz.Location = new System.Drawing.Point(220, 40);
            this.tb_lieferskontosatz.Name = "tb_lieferskontosatz";
            this.tb_lieferskontosatz.Size = new System.Drawing.Size(40, 20);
            this.tb_lieferskontosatz.TabIndex = 4;
            this.tb_lieferskontosatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "- Lieferskonto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Zieleinkaufspreis";
            // 
            // lbl_lieferskontosatz
            // 
            this.lbl_lieferskontosatz.AutoSize = true;
            this.lbl_lieferskontosatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_lieferskontosatz.Name = "lbl_lieferskontosatz";
            this.lbl_lieferskontosatz.Size = new System.Drawing.Size(84, 13);
            this.lbl_lieferskontosatz.TabIndex = 3;
            this.lbl_lieferskontosatz.Text = "Lieferskontosatz";
            // 
            // lbl_bareinkaufspreis
            // 
            this.lbl_bareinkaufspreis.AutoSize = true;
            this.lbl_bareinkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_bareinkaufspreis.Name = "lbl_bareinkaufspreis";
            this.lbl_bareinkaufspreis.Size = new System.Drawing.Size(94, 13);
            this.lbl_bareinkaufspreis.TabIndex = 6;
            this.lbl_bareinkaufspreis.Text = "= Bareinkaufspreis";
            // 
            // tb_bareinkaufspreis
            // 
            this.tb_bareinkaufspreis.Enabled = false;
            this.tb_bareinkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_bareinkaufspreis.Name = "tb_bareinkaufspreis";
            this.tb_bareinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_bareinkaufspreis.TabIndex = 8;
            this.tb_bareinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(280, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "von Hundert";
            // 
            // gb_einstandspreis
            // 
            this.gb_einstandspreis.Controls.Add(this.lbl_absolut);
            this.gb_einstandspreis.Controls.Add(this.tb_bareinkaufspreis_2);
            this.gb_einstandspreis.Controls.Add(this.tb_bezugskosten);
            this.gb_einstandspreis.Controls.Add(this.lbl_bareinkaufspreis_2);
            this.gb_einstandspreis.Controls.Add(this.lbl_bezugskosten);
            this.gb_einstandspreis.Controls.Add(this.lbl_einstandspreis);
            this.gb_einstandspreis.Controls.Add(this.tb_einstandspreis);
            this.gb_einstandspreis.Location = new System.Drawing.Point(0, 240);
            this.gb_einstandspreis.Name = "gb_einstandspreis";
            this.gb_einstandspreis.Size = new System.Drawing.Size(360, 100);
            this.gb_einstandspreis.TabIndex = 11;
            this.gb_einstandspreis.TabStop = false;
            this.gb_einstandspreis.Text = "Einstandspreis";
            // 
            // lbl_absolut
            // 
            this.lbl_absolut.AutoSize = true;
            this.lbl_absolut.Location = new System.Drawing.Point(280, 20);
            this.lbl_absolut.Name = "lbl_absolut";
            this.lbl_absolut.Size = new System.Drawing.Size(41, 13);
            this.lbl_absolut.TabIndex = 10;
            this.lbl_absolut.Text = "absolut";
            // 
            // tb_bareinkaufspreis_2
            // 
            this.tb_bareinkaufspreis_2.Enabled = false;
            this.tb_bareinkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_bareinkaufspreis_2.Name = "tb_bareinkaufspreis_2";
            this.tb_bareinkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_bareinkaufspreis_2.TabIndex = 1;
            this.tb_bareinkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_bezugskosten
            // 
            this.tb_bezugskosten.Location = new System.Drawing.Point(220, 40);
            this.tb_bezugskosten.Name = "tb_bezugskosten";
            this.tb_bezugskosten.Size = new System.Drawing.Size(40, 20);
            this.tb_bezugskosten.TabIndex = 4;
            this.tb_bezugskosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_bareinkaufspreis_2
            // 
            this.lbl_bareinkaufspreis_2.AutoSize = true;
            this.lbl_bareinkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_bareinkaufspreis_2.Name = "lbl_bareinkaufspreis_2";
            this.lbl_bareinkaufspreis_2.Size = new System.Drawing.Size(85, 13);
            this.lbl_bareinkaufspreis_2.TabIndex = 2;
            this.lbl_bareinkaufspreis_2.Text = "Bareinkaufspreis";
            // 
            // lbl_bezugskosten
            // 
            this.lbl_bezugskosten.AutoSize = true;
            this.lbl_bezugskosten.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bezugskosten.Location = new System.Drawing.Point(20, 40);
            this.lbl_bezugskosten.Name = "lbl_bezugskosten";
            this.lbl_bezugskosten.Size = new System.Drawing.Size(83, 13);
            this.lbl_bezugskosten.TabIndex = 3;
            this.lbl_bezugskosten.Text = "+ Bezugskosten";
            // 
            // lbl_einstandspreis
            // 
            this.lbl_einstandspreis.AutoSize = true;
            this.lbl_einstandspreis.Location = new System.Drawing.Point(20, 60);
            this.lbl_einstandspreis.Name = "lbl_einstandspreis";
            this.lbl_einstandspreis.Size = new System.Drawing.Size(84, 13);
            this.lbl_einstandspreis.TabIndex = 6;
            this.lbl_einstandspreis.Text = "= Einstandspreis";
            // 
            // tb_einstandspreis
            // 
            this.tb_einstandspreis.Enabled = false;
            this.tb_einstandspreis.Location = new System.Drawing.Point(160, 60);
            this.tb_einstandspreis.Name = "tb_einstandspreis";
            this.tb_einstandspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_einstandspreis.TabIndex = 8;
            this.tb_einstandspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_barverkaufspreis
            // 
            this.gb_barverkaufspreis.Controls.Add(this.tb_gewinn);
            this.gb_barverkaufspreis.Controls.Add(this.label4);
            this.gb_barverkaufspreis.Controls.Add(this.tb_selbstkostenpreis_2);
            this.gb_barverkaufspreis.Controls.Add(this.tb_gewinnsatz);
            this.gb_barverkaufspreis.Controls.Add(this.lbl_gewinn);
            this.gb_barverkaufspreis.Controls.Add(this.lbl_selbstkostenpreis_2);
            this.gb_barverkaufspreis.Controls.Add(this.lbl_gewinnsatz);
            this.gb_barverkaufspreis.Controls.Add(this.lbl_barverkaufspreis);
            this.gb_barverkaufspreis.Controls.Add(this.tb_barverkaufspreis);
            this.gb_barverkaufspreis.Location = new System.Drawing.Point(0, 460);
            this.gb_barverkaufspreis.Name = "gb_barverkaufspreis";
            this.gb_barverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_barverkaufspreis.TabIndex = 12;
            this.gb_barverkaufspreis.TabStop = false;
            this.gb_barverkaufspreis.Text = "Barverkaufspreis";
            // 
            // tb_gewinn
            // 
            this.tb_gewinn.Enabled = false;
            this.tb_gewinn.Location = new System.Drawing.Point(220, 60);
            this.tb_gewinn.Name = "tb_gewinn";
            this.tb_gewinn.Size = new System.Drawing.Size(40, 20);
            this.tb_gewinn.TabIndex = 11;
            this.tb_gewinn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(280, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "von Hundert";
            // 
            // tb_selbstkostenpreis_2
            // 
            this.tb_selbstkostenpreis_2.Enabled = false;
            this.tb_selbstkostenpreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_selbstkostenpreis_2.Name = "tb_selbstkostenpreis_2";
            this.tb_selbstkostenpreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_selbstkostenpreis_2.TabIndex = 1;
            this.tb_selbstkostenpreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_gewinnsatz
            // 
            this.tb_gewinnsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_gewinnsatz.Name = "tb_gewinnsatz";
            this.tb_gewinnsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_gewinnsatz.TabIndex = 4;
            this.tb_gewinnsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_gewinn
            // 
            this.lbl_gewinn.AutoSize = true;
            this.lbl_gewinn.Location = new System.Drawing.Point(20, 60);
            this.lbl_gewinn.Name = "lbl_gewinn";
            this.lbl_gewinn.Size = new System.Drawing.Size(52, 13);
            this.lbl_gewinn.TabIndex = 5;
            this.lbl_gewinn.Text = "+ Gewinn";
            // 
            // lbl_selbstkostenpreis_2
            // 
            this.lbl_selbstkostenpreis_2.AutoSize = true;
            this.lbl_selbstkostenpreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_selbstkostenpreis_2.Name = "lbl_selbstkostenpreis_2";
            this.lbl_selbstkostenpreis_2.Size = new System.Drawing.Size(90, 13);
            this.lbl_selbstkostenpreis_2.TabIndex = 2;
            this.lbl_selbstkostenpreis_2.Text = "Selbstkostenpreis";
            // 
            // lbl_gewinnsatz
            // 
            this.lbl_gewinnsatz.AutoSize = true;
            this.lbl_gewinnsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_gewinnsatz.Name = "lbl_gewinnsatz";
            this.lbl_gewinnsatz.Size = new System.Drawing.Size(62, 13);
            this.lbl_gewinnsatz.TabIndex = 3;
            this.lbl_gewinnsatz.Text = "Gewinnsatz";
            // 
            // lbl_barverkaufspreis
            // 
            this.lbl_barverkaufspreis.AutoSize = true;
            this.lbl_barverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_barverkaufspreis.Name = "lbl_barverkaufspreis";
            this.lbl_barverkaufspreis.Size = new System.Drawing.Size(95, 13);
            this.lbl_barverkaufspreis.TabIndex = 6;
            this.lbl_barverkaufspreis.Text = "= Barverkaufspreis";
            // 
            // tb_barverkaufspreis
            // 
            this.tb_barverkaufspreis.Enabled = false;
            this.tb_barverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_barverkaufspreis.Name = "tb_barverkaufspreis";
            this.tb_barverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_barverkaufspreis.TabIndex = 8;
            this.tb_barverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_selbstkostenpreis
            // 
            this.gb_selbstkostenpreis.Controls.Add(this.tb_handlungskosten);
            this.gb_selbstkostenpreis.Controls.Add(this.label5);
            this.gb_selbstkostenpreis.Controls.Add(this.tb_einstandspreis_2);
            this.gb_selbstkostenpreis.Controls.Add(this.tb_handlungskostensatz);
            this.gb_selbstkostenpreis.Controls.Add(this.lbl_handlungskosten);
            this.gb_selbstkostenpreis.Controls.Add(this.lbl_einstandspreis_2);
            this.gb_selbstkostenpreis.Controls.Add(this.lbl_handlungskostensatz);
            this.gb_selbstkostenpreis.Controls.Add(this.lbl_selbstkostenpreis);
            this.gb_selbstkostenpreis.Controls.Add(this.tb_selbstkostenpreis);
            this.gb_selbstkostenpreis.Location = new System.Drawing.Point(0, 340);
            this.gb_selbstkostenpreis.Name = "gb_selbstkostenpreis";
            this.gb_selbstkostenpreis.Size = new System.Drawing.Size(360, 120);
            this.gb_selbstkostenpreis.TabIndex = 13;
            this.gb_selbstkostenpreis.TabStop = false;
            this.gb_selbstkostenpreis.Text = "Selbstkostenpreis";
            // 
            // tb_handlungskosten
            // 
            this.tb_handlungskosten.Enabled = false;
            this.tb_handlungskosten.Location = new System.Drawing.Point(220, 60);
            this.tb_handlungskosten.Name = "tb_handlungskosten";
            this.tb_handlungskosten.Size = new System.Drawing.Size(40, 20);
            this.tb_handlungskosten.TabIndex = 11;
            this.tb_handlungskosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(280, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "von Hundert";
            // 
            // tb_einstandspreis_2
            // 
            this.tb_einstandspreis_2.Enabled = false;
            this.tb_einstandspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_einstandspreis_2.Name = "tb_einstandspreis_2";
            this.tb_einstandspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_einstandspreis_2.TabIndex = 1;
            this.tb_einstandspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_handlungskostensatz
            // 
            this.tb_handlungskostensatz.Location = new System.Drawing.Point(220, 40);
            this.tb_handlungskostensatz.Name = "tb_handlungskostensatz";
            this.tb_handlungskostensatz.Size = new System.Drawing.Size(40, 20);
            this.tb_handlungskostensatz.TabIndex = 4;
            this.tb_handlungskostensatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_handlungskosten
            // 
            this.lbl_handlungskosten.AutoSize = true;
            this.lbl_handlungskosten.Location = new System.Drawing.Point(20, 60);
            this.lbl_handlungskosten.Name = "lbl_handlungskosten";
            this.lbl_handlungskosten.Size = new System.Drawing.Size(99, 13);
            this.lbl_handlungskosten.TabIndex = 5;
            this.lbl_handlungskosten.Text = "+ Handlungskosten";
            // 
            // lbl_einstandspreis_2
            // 
            this.lbl_einstandspreis_2.AutoSize = true;
            this.lbl_einstandspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_einstandspreis_2.Name = "lbl_einstandspreis_2";
            this.lbl_einstandspreis_2.Size = new System.Drawing.Size(75, 13);
            this.lbl_einstandspreis_2.TabIndex = 2;
            this.lbl_einstandspreis_2.Text = "Einstandspreis";
            // 
            // lbl_handlungskostensatz
            // 
            this.lbl_handlungskostensatz.AutoSize = true;
            this.lbl_handlungskostensatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_handlungskostensatz.Name = "lbl_handlungskostensatz";
            this.lbl_handlungskostensatz.Size = new System.Drawing.Size(109, 13);
            this.lbl_handlungskostensatz.TabIndex = 3;
            this.lbl_handlungskostensatz.Text = "Handlungskostensatz";
            // 
            // lbl_selbstkostenpreis
            // 
            this.lbl_selbstkostenpreis.AutoSize = true;
            this.lbl_selbstkostenpreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_selbstkostenpreis.Name = "lbl_selbstkostenpreis";
            this.lbl_selbstkostenpreis.Size = new System.Drawing.Size(99, 13);
            this.lbl_selbstkostenpreis.TabIndex = 6;
            this.lbl_selbstkostenpreis.Text = "= Selbstkostenpreis";
            // 
            // tb_selbstkostenpreis
            // 
            this.tb_selbstkostenpreis.Enabled = false;
            this.tb_selbstkostenpreis.Location = new System.Drawing.Point(160, 80);
            this.tb_selbstkostenpreis.Name = "tb_selbstkostenpreis";
            this.tb_selbstkostenpreis.Size = new System.Drawing.Size(100, 20);
            this.tb_selbstkostenpreis.TabIndex = 8;
            this.tb_selbstkostenpreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_zielverkaufspreis
            // 
            this.gb_zielverkaufspreis.Controls.Add(this.groupBox1);
            this.gb_zielverkaufspreis.Controls.Add(this.tb_kundenskonto);
            this.gb_zielverkaufspreis.Controls.Add(this.label7);
            this.gb_zielverkaufspreis.Controls.Add(this.tb_barverkaufspreis_2);
            this.gb_zielverkaufspreis.Controls.Add(this.tb_kundenskontosatz);
            this.gb_zielverkaufspreis.Controls.Add(this.lbl_kundenskonto);
            this.gb_zielverkaufspreis.Controls.Add(this.lbl_barverkaufspreis_2);
            this.gb_zielverkaufspreis.Controls.Add(this.lbl_kundenskontosatz);
            this.gb_zielverkaufspreis.Controls.Add(this.lbl_zielverkaufspreis);
            this.gb_zielverkaufspreis.Controls.Add(this.tb_zielverkaufspreis);
            this.gb_zielverkaufspreis.Location = new System.Drawing.Point(0, 580);
            this.gb_zielverkaufspreis.Name = "gb_zielverkaufspreis";
            this.gb_zielverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_zielverkaufspreis.TabIndex = 13;
            this.gb_zielverkaufspreis.TabStop = false;
            this.gb_zielverkaufspreis.Text = "Zielverkaufspreis";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Location = new System.Drawing.Point(0, 140);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(280, 140);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Zielverkaufspreis";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(220, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(40, 20);
            this.textBox1.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(200, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "in Hundert";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(160, 40);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(220, 60);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(40, 20);
            this.textBox3.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "+ Kundenskonto";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Barverkaufspreis";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Kundenskontosatz";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "= Zielverkaufspreis";
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Location = new System.Drawing.Point(160, 100);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 8;
            // 
            // tb_kundenskonto
            // 
            this.tb_kundenskonto.Enabled = false;
            this.tb_kundenskonto.Location = new System.Drawing.Point(220, 60);
            this.tb_kundenskonto.Name = "tb_kundenskonto";
            this.tb_kundenskonto.Size = new System.Drawing.Size(40, 20);
            this.tb_kundenskonto.TabIndex = 11;
            this.tb_kundenskonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(280, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "in Hundert";
            // 
            // tb_barverkaufspreis_2
            // 
            this.tb_barverkaufspreis_2.Enabled = false;
            this.tb_barverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_barverkaufspreis_2.Name = "tb_barverkaufspreis_2";
            this.tb_barverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_barverkaufspreis_2.TabIndex = 1;
            this.tb_barverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_kundenskontosatz
            // 
            this.tb_kundenskontosatz.Location = new System.Drawing.Point(220, 40);
            this.tb_kundenskontosatz.Name = "tb_kundenskontosatz";
            this.tb_kundenskontosatz.Size = new System.Drawing.Size(40, 20);
            this.tb_kundenskontosatz.TabIndex = 4;
            this.tb_kundenskontosatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_kundenskonto
            // 
            this.lbl_kundenskonto.AutoSize = true;
            this.lbl_kundenskonto.Location = new System.Drawing.Point(20, 60);
            this.lbl_kundenskonto.Name = "lbl_kundenskonto";
            this.lbl_kundenskonto.Size = new System.Drawing.Size(85, 13);
            this.lbl_kundenskonto.TabIndex = 5;
            this.lbl_kundenskonto.Text = "+ Kundenskonto";
            // 
            // lbl_barverkaufspreis_2
            // 
            this.lbl_barverkaufspreis_2.AutoSize = true;
            this.lbl_barverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_barverkaufspreis_2.Name = "lbl_barverkaufspreis_2";
            this.lbl_barverkaufspreis_2.Size = new System.Drawing.Size(86, 13);
            this.lbl_barverkaufspreis_2.TabIndex = 2;
            this.lbl_barverkaufspreis_2.Text = "Barverkaufspreis";
            // 
            // lbl_kundenskontosatz
            // 
            this.lbl_kundenskontosatz.AutoSize = true;
            this.lbl_kundenskontosatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_kundenskontosatz.Name = "lbl_kundenskontosatz";
            this.lbl_kundenskontosatz.Size = new System.Drawing.Size(95, 13);
            this.lbl_kundenskontosatz.TabIndex = 3;
            this.lbl_kundenskontosatz.Text = "Kundenskontosatz";
            // 
            // lbl_zielverkaufspreis
            // 
            this.lbl_zielverkaufspreis.AutoSize = true;
            this.lbl_zielverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_zielverkaufspreis.Name = "lbl_zielverkaufspreis";
            this.lbl_zielverkaufspreis.Size = new System.Drawing.Size(96, 13);
            this.lbl_zielverkaufspreis.TabIndex = 6;
            this.lbl_zielverkaufspreis.Text = "= Zielverkaufspreis";
            // 
            // tb_zielverkaufspreis
            // 
            this.tb_zielverkaufspreis.Enabled = false;
            this.tb_zielverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_zielverkaufspreis.Name = "tb_zielverkaufspreis";
            this.tb_zielverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_zielverkaufspreis.TabIndex = 8;
            this.tb_zielverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_nettolistenverkaufspreis
            // 
            this.gb_nettolistenverkaufspreis.Controls.Add(this.groupBox3);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.tb_kundenrabatt);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.label18);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.tb_zielverkaufspreis_2);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.tb_kundenrabattsatz);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.lbl_kundenrabatt);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.lbl_zielverkaufspreis_2);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.lbl_kundenrabattsatz);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.label22);
            this.gb_nettolistenverkaufspreis.Controls.Add(this.tb_nettolistenverkaufspreis);
            this.gb_nettolistenverkaufspreis.Location = new System.Drawing.Point(0, 700);
            this.gb_nettolistenverkaufspreis.Name = "gb_nettolistenverkaufspreis";
            this.gb_nettolistenverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_nettolistenverkaufspreis.TabIndex = 15;
            this.gb_nettolistenverkaufspreis.TabStop = false;
            this.gb_nettolistenverkaufspreis.Text = "Nettolistenverkaufspreis";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Location = new System.Drawing.Point(0, 140);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(280, 140);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Zielverkaufspreis";
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Location = new System.Drawing.Point(220, 80);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(40, 20);
            this.textBox5.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(200, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 13);
            this.label13.TabIndex = 10;
            this.label13.Text = "in Hundert";
            // 
            // textBox6
            // 
            this.textBox6.Enabled = false;
            this.textBox6.Location = new System.Drawing.Point(160, 40);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 1;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(220, 60);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(40, 20);
            this.textBox7.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 80);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "+ Kundenskonto";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(20, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Barverkaufspreis";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 60);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "Kundenskontosatz";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 100);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 13);
            this.label17.TabIndex = 6;
            this.label17.Text = "= Zielverkaufspreis";
            // 
            // textBox8
            // 
            this.textBox8.Enabled = false;
            this.textBox8.Location = new System.Drawing.Point(160, 100);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 8;
            // 
            // tb_kundenrabatt
            // 
            this.tb_kundenrabatt.Enabled = false;
            this.tb_kundenrabatt.Location = new System.Drawing.Point(220, 60);
            this.tb_kundenrabatt.Name = "tb_kundenrabatt";
            this.tb_kundenrabatt.Size = new System.Drawing.Size(40, 20);
            this.tb_kundenrabatt.TabIndex = 11;
            this.tb_kundenrabatt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(280, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 13);
            this.label18.TabIndex = 10;
            this.label18.Text = "in Hundert";
            // 
            // tb_zielverkaufspreis_2
            // 
            this.tb_zielverkaufspreis_2.Enabled = false;
            this.tb_zielverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_zielverkaufspreis_2.Name = "tb_zielverkaufspreis_2";
            this.tb_zielverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_zielverkaufspreis_2.TabIndex = 1;
            this.tb_zielverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_kundenrabattsatz
            // 
            this.tb_kundenrabattsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_kundenrabattsatz.Name = "tb_kundenrabattsatz";
            this.tb_kundenrabattsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_kundenrabattsatz.TabIndex = 4;
            this.tb_kundenrabattsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_kundenrabatt
            // 
            this.lbl_kundenrabatt.AutoSize = true;
            this.lbl_kundenrabatt.Location = new System.Drawing.Point(20, 60);
            this.lbl_kundenrabatt.Name = "lbl_kundenrabatt";
            this.lbl_kundenrabatt.Size = new System.Drawing.Size(80, 13);
            this.lbl_kundenrabatt.TabIndex = 5;
            this.lbl_kundenrabatt.Text = "+ Kundenrabatt";
            // 
            // lbl_zielverkaufspreis_2
            // 
            this.lbl_zielverkaufspreis_2.AutoSize = true;
            this.lbl_zielverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_zielverkaufspreis_2.Name = "lbl_zielverkaufspreis_2";
            this.lbl_zielverkaufspreis_2.Size = new System.Drawing.Size(87, 13);
            this.lbl_zielverkaufspreis_2.TabIndex = 2;
            this.lbl_zielverkaufspreis_2.Text = "Zielverkaufspreis";
            // 
            // lbl_kundenrabattsatz
            // 
            this.lbl_kundenrabattsatz.AutoSize = true;
            this.lbl_kundenrabattsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_kundenrabattsatz.Name = "lbl_kundenrabattsatz";
            this.lbl_kundenrabattsatz.Size = new System.Drawing.Size(90, 13);
            this.lbl_kundenrabattsatz.TabIndex = 3;
            this.lbl_kundenrabattsatz.Text = "Kundenrabattsatz";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 80);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(129, 13);
            this.label22.TabIndex = 6;
            this.label22.Text = "= Nettolistenverkaufspreis";
            // 
            // tb_nettolistenverkaufspreis
            // 
            this.tb_nettolistenverkaufspreis.Enabled = false;
            this.tb_nettolistenverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_nettolistenverkaufspreis.Name = "tb_nettolistenverkaufspreis";
            this.tb_nettolistenverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_nettolistenverkaufspreis.TabIndex = 8;
            this.tb_nettolistenverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_bruttoverkaufspreis
            // 
            this.gb_bruttoverkaufspreis.Controls.Add(this.groupBox4);
            this.gb_bruttoverkaufspreis.Controls.Add(this.tb_umsatzsteuer);
            this.gb_bruttoverkaufspreis.Controls.Add(this.label25);
            this.gb_bruttoverkaufspreis.Controls.Add(this.tb_nettolistenverkaufspreis_2);
            this.gb_bruttoverkaufspreis.Controls.Add(this.tb_umsatzsteuersatz);
            this.gb_bruttoverkaufspreis.Controls.Add(this.lbl_umsatzsteuer);
            this.gb_bruttoverkaufspreis.Controls.Add(this.lbl_nettolistenverkaufspreis_2);
            this.gb_bruttoverkaufspreis.Controls.Add(this.lbl_umsatzsteuersatz);
            this.gb_bruttoverkaufspreis.Controls.Add(this.lbl_bruttoverkaufspreis);
            this.gb_bruttoverkaufspreis.Controls.Add(this.tb_bruttoverkaufspreis);
            this.gb_bruttoverkaufspreis.Location = new System.Drawing.Point(0, 820);
            this.gb_bruttoverkaufspreis.Name = "gb_bruttoverkaufspreis";
            this.gb_bruttoverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_bruttoverkaufspreis.TabIndex = 16;
            this.gb_bruttoverkaufspreis.TabStop = false;
            this.gb_bruttoverkaufspreis.Text = "Bruttoverkaufspreis";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Location = new System.Drawing.Point(0, 140);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(280, 140);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Zielverkaufspreis";
            // 
            // textBox9
            // 
            this.textBox9.Enabled = false;
            this.textBox9.Location = new System.Drawing.Point(220, 80);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(40, 20);
            this.textBox9.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(200, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 13);
            this.label19.TabIndex = 10;
            this.label19.Text = "in Hundert";
            // 
            // textBox10
            // 
            this.textBox10.Enabled = false;
            this.textBox10.Location = new System.Drawing.Point(160, 40);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 1;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(220, 60);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(40, 20);
            this.textBox11.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(20, 80);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(85, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "+ Kundenskonto";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(20, 40);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(86, 13);
            this.label21.TabIndex = 2;
            this.label21.Text = "Barverkaufspreis";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 60);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(95, 13);
            this.label23.TabIndex = 3;
            this.label23.Text = "Kundenskontosatz";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 100);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(96, 13);
            this.label24.TabIndex = 6;
            this.label24.Text = "= Zielverkaufspreis";
            // 
            // textBox12
            // 
            this.textBox12.Enabled = false;
            this.textBox12.Location = new System.Drawing.Point(160, 100);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 8;
            // 
            // tb_umsatzsteuer
            // 
            this.tb_umsatzsteuer.Enabled = false;
            this.tb_umsatzsteuer.Location = new System.Drawing.Point(220, 60);
            this.tb_umsatzsteuer.Name = "tb_umsatzsteuer";
            this.tb_umsatzsteuer.Size = new System.Drawing.Size(40, 20);
            this.tb_umsatzsteuer.TabIndex = 11;
            this.tb_umsatzsteuer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(280, 20);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(66, 13);
            this.label25.TabIndex = 10;
            this.label25.Text = "von Hundert";
            // 
            // tb_nettolistenverkaufspreis_2
            // 
            this.tb_nettolistenverkaufspreis_2.Enabled = false;
            this.tb_nettolistenverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_nettolistenverkaufspreis_2.Name = "tb_nettolistenverkaufspreis_2";
            this.tb_nettolistenverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_nettolistenverkaufspreis_2.TabIndex = 1;
            this.tb_nettolistenverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_umsatzsteuersatz
            // 
            this.tb_umsatzsteuersatz.Location = new System.Drawing.Point(220, 40);
            this.tb_umsatzsteuersatz.Name = "tb_umsatzsteuersatz";
            this.tb_umsatzsteuersatz.Size = new System.Drawing.Size(40, 20);
            this.tb_umsatzsteuersatz.TabIndex = 4;
            this.tb_umsatzsteuersatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_umsatzsteuer
            // 
            this.lbl_umsatzsteuer.AutoSize = true;
            this.lbl_umsatzsteuer.Location = new System.Drawing.Point(20, 60);
            this.lbl_umsatzsteuer.Name = "lbl_umsatzsteuer";
            this.lbl_umsatzsteuer.Size = new System.Drawing.Size(80, 13);
            this.lbl_umsatzsteuer.TabIndex = 5;
            this.lbl_umsatzsteuer.Text = "+ Umsatzsteuer";
            // 
            // lbl_nettolistenverkaufspreis_2
            // 
            this.lbl_nettolistenverkaufspreis_2.AutoSize = true;
            this.lbl_nettolistenverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_nettolistenverkaufspreis_2.Name = "lbl_nettolistenverkaufspreis_2";
            this.lbl_nettolistenverkaufspreis_2.Size = new System.Drawing.Size(120, 13);
            this.lbl_nettolistenverkaufspreis_2.TabIndex = 2;
            this.lbl_nettolistenverkaufspreis_2.Text = "Nettolistenverkaufspreis";
            // 
            // lbl_umsatzsteuersatz
            // 
            this.lbl_umsatzsteuersatz.AutoSize = true;
            this.lbl_umsatzsteuersatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_umsatzsteuersatz.Name = "lbl_umsatzsteuersatz";
            this.lbl_umsatzsteuersatz.Size = new System.Drawing.Size(90, 13);
            this.lbl_umsatzsteuersatz.TabIndex = 3;
            this.lbl_umsatzsteuersatz.Text = "Umsatzsteuersatz";
            // 
            // lbl_bruttoverkaufspreis
            // 
            this.lbl_bruttoverkaufspreis.AutoSize = true;
            this.lbl_bruttoverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_bruttoverkaufspreis.Name = "lbl_bruttoverkaufspreis";
            this.lbl_bruttoverkaufspreis.Size = new System.Drawing.Size(107, 13);
            this.lbl_bruttoverkaufspreis.TabIndex = 6;
            this.lbl_bruttoverkaufspreis.Text = "= Bruttoverkaufspreis";
            // 
            // tb_bruttoverkaufspreis
            // 
            this.tb_bruttoverkaufspreis.Enabled = false;
            this.tb_bruttoverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_bruttoverkaufspreis.Name = "tb_bruttoverkaufspreis";
            this.tb_bruttoverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_bruttoverkaufspreis.TabIndex = 8;
            this.tb_bruttoverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_nettolistenverkaufspreis
            // 
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.groupBox5);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.tb_r_umsatzsteuer);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.label31);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.tb_r_nettolistenverkaufspreis);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.tb_r_umsatzsteuersatz);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.lbl_r_umsatzsteuer);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.lbl_r_nettolistenverkaufspreis);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.lbl_r_umsatzsteuersatz);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.lbl_r_bruttoverkaufspreis);
            this.gb_r_nettolistenverkaufspreis.Controls.Add(this.tb_r_bruttoverkaufspreis);
            this.gb_r_nettolistenverkaufspreis.Location = new System.Drawing.Point(380, 820);
            this.gb_r_nettolistenverkaufspreis.Name = "gb_r_nettolistenverkaufspreis";
            this.gb_r_nettolistenverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_nettolistenverkaufspreis.TabIndex = 17;
            this.gb_r_nettolistenverkaufspreis.TabStop = false;
            this.gb_r_nettolistenverkaufspreis.Text = "Nettolistenverkaufspreis";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox13);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.textBox14);
            this.groupBox5.Controls.Add(this.textBox15);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.textBox16);
            this.groupBox5.Location = new System.Drawing.Point(0, 140);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(280, 140);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Zielverkaufspreis";
            // 
            // textBox13
            // 
            this.textBox13.Enabled = false;
            this.textBox13.Location = new System.Drawing.Point(220, 80);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(40, 20);
            this.textBox13.TabIndex = 11;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(200, 20);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 13);
            this.label26.TabIndex = 10;
            this.label26.Text = "in Hundert";
            // 
            // textBox14
            // 
            this.textBox14.Enabled = false;
            this.textBox14.Location = new System.Drawing.Point(160, 40);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 20);
            this.textBox14.TabIndex = 1;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(220, 60);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(40, 20);
            this.textBox15.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(20, 80);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(85, 13);
            this.label27.TabIndex = 5;
            this.label27.Text = "+ Kundenskonto";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(20, 40);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 13);
            this.label28.TabIndex = 2;
            this.label28.Text = "Barverkaufspreis";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(20, 60);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(95, 13);
            this.label29.TabIndex = 3;
            this.label29.Text = "Kundenskontosatz";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(20, 100);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(96, 13);
            this.label30.TabIndex = 6;
            this.label30.Text = "= Zielverkaufspreis";
            // 
            // textBox16
            // 
            this.textBox16.Enabled = false;
            this.textBox16.Location = new System.Drawing.Point(160, 100);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 20);
            this.textBox16.TabIndex = 8;
            // 
            // tb_r_umsatzsteuer
            // 
            this.tb_r_umsatzsteuer.Enabled = false;
            this.tb_r_umsatzsteuer.Location = new System.Drawing.Point(220, 60);
            this.tb_r_umsatzsteuer.Name = "tb_r_umsatzsteuer";
            this.tb_r_umsatzsteuer.Size = new System.Drawing.Size(40, 20);
            this.tb_r_umsatzsteuer.TabIndex = 11;
            this.tb_r_umsatzsteuer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(280, 20);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(63, 13);
            this.label31.TabIndex = 10;
            this.label31.Text = "auf Hundert";
            // 
            // tb_r_nettolistenverkaufspreis
            // 
            this.tb_r_nettolistenverkaufspreis.Enabled = false;
            this.tb_r_nettolistenverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_nettolistenverkaufspreis.Name = "tb_r_nettolistenverkaufspreis";
            this.tb_r_nettolistenverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_nettolistenverkaufspreis.TabIndex = 1;
            this.tb_r_nettolistenverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_umsatzsteuersatz
            // 
            this.tb_r_umsatzsteuersatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_umsatzsteuersatz.Name = "tb_r_umsatzsteuersatz";
            this.tb_r_umsatzsteuersatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_umsatzsteuersatz.TabIndex = 4;
            this.tb_r_umsatzsteuersatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_umsatzsteuer
            // 
            this.lbl_r_umsatzsteuer.AutoSize = true;
            this.lbl_r_umsatzsteuer.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_umsatzsteuer.Name = "lbl_r_umsatzsteuer";
            this.lbl_r_umsatzsteuer.Size = new System.Drawing.Size(77, 13);
            this.lbl_r_umsatzsteuer.TabIndex = 5;
            this.lbl_r_umsatzsteuer.Text = "- Umsatzsteuer";
            // 
            // lbl_r_nettolistenverkaufspreis
            // 
            this.lbl_r_nettolistenverkaufspreis.AutoSize = true;
            this.lbl_r_nettolistenverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_nettolistenverkaufspreis.Name = "lbl_r_nettolistenverkaufspreis";
            this.lbl_r_nettolistenverkaufspreis.Size = new System.Drawing.Size(129, 13);
            this.lbl_r_nettolistenverkaufspreis.TabIndex = 2;
            this.lbl_r_nettolistenverkaufspreis.Text = "= Nettolistenverkaufspreis";
            // 
            // lbl_r_umsatzsteuersatz
            // 
            this.lbl_r_umsatzsteuersatz.AutoSize = true;
            this.lbl_r_umsatzsteuersatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_umsatzsteuersatz.Name = "lbl_r_umsatzsteuersatz";
            this.lbl_r_umsatzsteuersatz.Size = new System.Drawing.Size(90, 13);
            this.lbl_r_umsatzsteuersatz.TabIndex = 3;
            this.lbl_r_umsatzsteuersatz.Text = "Umsatzsteuersatz";
            // 
            // lbl_r_bruttoverkaufspreis
            // 
            this.lbl_r_bruttoverkaufspreis.AutoSize = true;
            this.lbl_r_bruttoverkaufspreis.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_bruttoverkaufspreis.Name = "lbl_r_bruttoverkaufspreis";
            this.lbl_r_bruttoverkaufspreis.Size = new System.Drawing.Size(98, 13);
            this.lbl_r_bruttoverkaufspreis.TabIndex = 6;
            this.lbl_r_bruttoverkaufspreis.Text = "Bruttoverkaufspreis";
            // 
            // tb_r_bruttoverkaufspreis
            // 
            this.tb_r_bruttoverkaufspreis.Location = new System.Drawing.Point(160, 20);
            this.tb_r_bruttoverkaufspreis.Name = "tb_r_bruttoverkaufspreis";
            this.tb_r_bruttoverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_bruttoverkaufspreis.TabIndex = 8;
            this.tb_r_bruttoverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_rueckwaertskalkulation
            // 
            this.btn_rueckwaertskalkulation.Location = new System.Drawing.Point(480, 960);
            this.btn_rueckwaertskalkulation.Name = "btn_rueckwaertskalkulation";
            this.btn_rueckwaertskalkulation.Size = new System.Drawing.Size(160, 23);
            this.btn_rueckwaertskalkulation.TabIndex = 18;
            this.btn_rueckwaertskalkulation.Text = "Berechne Rückwärts";
            this.btn_rueckwaertskalkulation.UseVisualStyleBackColor = true;
            this.btn_rueckwaertskalkulation.Click += new System.EventHandler(this.btn_rueckwaertskalkulation_Click);
            // 
            // gb_r_zielverkaufspreis
            // 
            this.gb_r_zielverkaufspreis.Controls.Add(this.groupBox6);
            this.gb_r_zielverkaufspreis.Controls.Add(this.tb_r_kundenrabatt);
            this.gb_r_zielverkaufspreis.Controls.Add(this.label36);
            this.gb_r_zielverkaufspreis.Controls.Add(this.tb_r_zielverkaufspreis);
            this.gb_r_zielverkaufspreis.Controls.Add(this.tb_r_kundenrabattsatz);
            this.gb_r_zielverkaufspreis.Controls.Add(this.lbl_r_kundenrabatt);
            this.gb_r_zielverkaufspreis.Controls.Add(this.lbl_r_zielverkaufspreis);
            this.gb_r_zielverkaufspreis.Controls.Add(this.lbl_r_kundenrabattsatz);
            this.gb_r_zielverkaufspreis.Controls.Add(this.lbl_r_nettolistenverkaufspreis_2);
            this.gb_r_zielverkaufspreis.Controls.Add(this.tb_r_nettolistenverkaufspreis_2);
            this.gb_r_zielverkaufspreis.Location = new System.Drawing.Point(380, 700);
            this.gb_r_zielverkaufspreis.Name = "gb_r_zielverkaufspreis";
            this.gb_r_zielverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_zielverkaufspreis.TabIndex = 16;
            this.gb_r_zielverkaufspreis.TabStop = false;
            this.gb_r_zielverkaufspreis.Text = "Zielverkaufspreis";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox17);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Controls.Add(this.textBox18);
            this.groupBox6.Controls.Add(this.textBox19);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.textBox20);
            this.groupBox6.Location = new System.Drawing.Point(0, 140);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(280, 140);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Zielverkaufspreis";
            // 
            // textBox17
            // 
            this.textBox17.Enabled = false;
            this.textBox17.Location = new System.Drawing.Point(220, 80);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(40, 20);
            this.textBox17.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(200, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "in Hundert";
            // 
            // textBox18
            // 
            this.textBox18.Enabled = false;
            this.textBox18.Location = new System.Drawing.Point(160, 40);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 20);
            this.textBox18.TabIndex = 1;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(220, 60);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(40, 20);
            this.textBox19.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(20, 80);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 13);
            this.label32.TabIndex = 5;
            this.label32.Text = "+ Kundenskonto";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(20, 40);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(86, 13);
            this.label33.TabIndex = 2;
            this.label33.Text = "Barverkaufspreis";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(20, 60);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(95, 13);
            this.label34.TabIndex = 3;
            this.label34.Text = "Kundenskontosatz";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(20, 100);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(96, 13);
            this.label35.TabIndex = 6;
            this.label35.Text = "= Zielverkaufspreis";
            // 
            // textBox20
            // 
            this.textBox20.Enabled = false;
            this.textBox20.Location = new System.Drawing.Point(160, 100);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 20);
            this.textBox20.TabIndex = 8;
            // 
            // tb_r_kundenrabatt
            // 
            this.tb_r_kundenrabatt.Enabled = false;
            this.tb_r_kundenrabatt.Location = new System.Drawing.Point(220, 60);
            this.tb_r_kundenrabatt.Name = "tb_r_kundenrabatt";
            this.tb_r_kundenrabatt.Size = new System.Drawing.Size(40, 20);
            this.tb_r_kundenrabatt.TabIndex = 11;
            this.tb_r_kundenrabatt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(280, 20);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(66, 13);
            this.label36.TabIndex = 10;
            this.label36.Text = "von Hundert";
            // 
            // tb_r_zielverkaufspreis
            // 
            this.tb_r_zielverkaufspreis.Enabled = false;
            this.tb_r_zielverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_zielverkaufspreis.Name = "tb_r_zielverkaufspreis";
            this.tb_r_zielverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_zielverkaufspreis.TabIndex = 1;
            this.tb_r_zielverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_kundenrabattsatz
            // 
            this.tb_r_kundenrabattsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_kundenrabattsatz.Name = "tb_r_kundenrabattsatz";
            this.tb_r_kundenrabattsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_kundenrabattsatz.TabIndex = 4;
            this.tb_r_kundenrabattsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_kundenrabatt
            // 
            this.lbl_r_kundenrabatt.AutoSize = true;
            this.lbl_r_kundenrabatt.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_kundenrabatt.Name = "lbl_r_kundenrabatt";
            this.lbl_r_kundenrabatt.Size = new System.Drawing.Size(77, 13);
            this.lbl_r_kundenrabatt.TabIndex = 5;
            this.lbl_r_kundenrabatt.Text = "- Kundenrabatt";
            // 
            // lbl_r_zielverkaufspreis
            // 
            this.lbl_r_zielverkaufspreis.AutoSize = true;
            this.lbl_r_zielverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_zielverkaufspreis.Name = "lbl_r_zielverkaufspreis";
            this.lbl_r_zielverkaufspreis.Size = new System.Drawing.Size(96, 13);
            this.lbl_r_zielverkaufspreis.TabIndex = 2;
            this.lbl_r_zielverkaufspreis.Text = "= Zielverkaufspreis";
            // 
            // lbl_r_kundenrabattsatz
            // 
            this.lbl_r_kundenrabattsatz.AutoSize = true;
            this.lbl_r_kundenrabattsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_kundenrabattsatz.Name = "lbl_r_kundenrabattsatz";
            this.lbl_r_kundenrabattsatz.Size = new System.Drawing.Size(90, 13);
            this.lbl_r_kundenrabattsatz.TabIndex = 3;
            this.lbl_r_kundenrabattsatz.Text = "Kundenrabattsatz";
            // 
            // lbl_r_nettolistenverkaufspreis_2
            // 
            this.lbl_r_nettolistenverkaufspreis_2.AutoSize = true;
            this.lbl_r_nettolistenverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_nettolistenverkaufspreis_2.Name = "lbl_r_nettolistenverkaufspreis_2";
            this.lbl_r_nettolistenverkaufspreis_2.Size = new System.Drawing.Size(120, 13);
            this.lbl_r_nettolistenverkaufspreis_2.TabIndex = 6;
            this.lbl_r_nettolistenverkaufspreis_2.Text = "Nettolistenverkaufspreis";
            // 
            // tb_r_nettolistenverkaufspreis_2
            // 
            this.tb_r_nettolistenverkaufspreis_2.Enabled = false;
            this.tb_r_nettolistenverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_nettolistenverkaufspreis_2.Name = "tb_r_nettolistenverkaufspreis_2";
            this.tb_r_nettolistenverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_nettolistenverkaufspreis_2.TabIndex = 8;
            this.tb_r_nettolistenverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_barverkaufspreis
            // 
            this.gb_r_barverkaufspreis.Controls.Add(this.groupBox7);
            this.gb_r_barverkaufspreis.Controls.Add(this.tb_r_kundenskonto);
            this.gb_r_barverkaufspreis.Controls.Add(this.label42);
            this.gb_r_barverkaufspreis.Controls.Add(this.tb_r_barverkaufspreis);
            this.gb_r_barverkaufspreis.Controls.Add(this.tb_r_kundenskontosatz);
            this.gb_r_barverkaufspreis.Controls.Add(this.lbl_r_kundenskonto);
            this.gb_r_barverkaufspreis.Controls.Add(this.lbl_r_barverkaufspreis);
            this.gb_r_barverkaufspreis.Controls.Add(this.lbl_r_kundenskontosatz);
            this.gb_r_barverkaufspreis.Controls.Add(this.lbl_r_zielverkaufspreis_2);
            this.gb_r_barverkaufspreis.Controls.Add(this.tb_r_zielverkaufspreis_2);
            this.gb_r_barverkaufspreis.Location = new System.Drawing.Point(380, 580);
            this.gb_r_barverkaufspreis.Name = "gb_r_barverkaufspreis";
            this.gb_r_barverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_barverkaufspreis.TabIndex = 17;
            this.gb_r_barverkaufspreis.TabStop = false;
            this.gb_r_barverkaufspreis.Text = "Barverkaufspreis";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBox21);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Controls.Add(this.textBox22);
            this.groupBox7.Controls.Add(this.textBox23);
            this.groupBox7.Controls.Add(this.label38);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Controls.Add(this.textBox24);
            this.groupBox7.Location = new System.Drawing.Point(0, 140);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(280, 140);
            this.groupBox7.TabIndex = 14;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Zielverkaufspreis";
            // 
            // textBox21
            // 
            this.textBox21.Enabled = false;
            this.textBox21.Location = new System.Drawing.Point(220, 80);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(40, 20);
            this.textBox21.TabIndex = 11;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(200, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(56, 13);
            this.label37.TabIndex = 10;
            this.label37.Text = "in Hundert";
            // 
            // textBox22
            // 
            this.textBox22.Enabled = false;
            this.textBox22.Location = new System.Drawing.Point(160, 40);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 20);
            this.textBox22.TabIndex = 1;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(220, 60);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(40, 20);
            this.textBox23.TabIndex = 4;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(20, 80);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(85, 13);
            this.label38.TabIndex = 5;
            this.label38.Text = "+ Kundenskonto";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(20, 40);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(86, 13);
            this.label39.TabIndex = 2;
            this.label39.Text = "Barverkaufspreis";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(20, 60);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 13);
            this.label40.TabIndex = 3;
            this.label40.Text = "Kundenskontosatz";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(20, 100);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(96, 13);
            this.label41.TabIndex = 6;
            this.label41.Text = "= Zielverkaufspreis";
            // 
            // textBox24
            // 
            this.textBox24.Enabled = false;
            this.textBox24.Location = new System.Drawing.Point(160, 100);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 20);
            this.textBox24.TabIndex = 8;
            // 
            // tb_r_kundenskonto
            // 
            this.tb_r_kundenskonto.Enabled = false;
            this.tb_r_kundenskonto.Location = new System.Drawing.Point(220, 60);
            this.tb_r_kundenskonto.Name = "tb_r_kundenskonto";
            this.tb_r_kundenskonto.Size = new System.Drawing.Size(40, 20);
            this.tb_r_kundenskonto.TabIndex = 11;
            this.tb_r_kundenskonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(280, 20);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(66, 13);
            this.label42.TabIndex = 10;
            this.label42.Text = "von Hundert";
            // 
            // tb_r_barverkaufspreis
            // 
            this.tb_r_barverkaufspreis.Enabled = false;
            this.tb_r_barverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_barverkaufspreis.Name = "tb_r_barverkaufspreis";
            this.tb_r_barverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_barverkaufspreis.TabIndex = 1;
            this.tb_r_barverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_kundenskontosatz
            // 
            this.tb_r_kundenskontosatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_kundenskontosatz.Name = "tb_r_kundenskontosatz";
            this.tb_r_kundenskontosatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_kundenskontosatz.TabIndex = 4;
            this.tb_r_kundenskontosatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_kundenskonto
            // 
            this.lbl_r_kundenskonto.AutoSize = true;
            this.lbl_r_kundenskonto.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_kundenskonto.Name = "lbl_r_kundenskonto";
            this.lbl_r_kundenskonto.Size = new System.Drawing.Size(82, 13);
            this.lbl_r_kundenskonto.TabIndex = 5;
            this.lbl_r_kundenskonto.Text = "- Kundenskonto";
            // 
            // lbl_r_barverkaufspreis
            // 
            this.lbl_r_barverkaufspreis.AutoSize = true;
            this.lbl_r_barverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_barverkaufspreis.Name = "lbl_r_barverkaufspreis";
            this.lbl_r_barverkaufspreis.Size = new System.Drawing.Size(95, 13);
            this.lbl_r_barverkaufspreis.TabIndex = 2;
            this.lbl_r_barverkaufspreis.Text = "= Barverkaufspreis";
            // 
            // lbl_r_kundenskontosatz
            // 
            this.lbl_r_kundenskontosatz.AutoSize = true;
            this.lbl_r_kundenskontosatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_kundenskontosatz.Name = "lbl_r_kundenskontosatz";
            this.lbl_r_kundenskontosatz.Size = new System.Drawing.Size(95, 13);
            this.lbl_r_kundenskontosatz.TabIndex = 3;
            this.lbl_r_kundenskontosatz.Text = "Kundenskontosatz";
            // 
            // lbl_r_zielverkaufspreis_2
            // 
            this.lbl_r_zielverkaufspreis_2.AutoSize = true;
            this.lbl_r_zielverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_zielverkaufspreis_2.Name = "lbl_r_zielverkaufspreis_2";
            this.lbl_r_zielverkaufspreis_2.Size = new System.Drawing.Size(87, 13);
            this.lbl_r_zielverkaufspreis_2.TabIndex = 6;
            this.lbl_r_zielverkaufspreis_2.Text = "Zielverkaufspreis";
            // 
            // tb_r_zielverkaufspreis_2
            // 
            this.tb_r_zielverkaufspreis_2.Enabled = false;
            this.tb_r_zielverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_zielverkaufspreis_2.Name = "tb_r_zielverkaufspreis_2";
            this.tb_r_zielverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_zielverkaufspreis_2.TabIndex = 8;
            this.tb_r_zielverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_selbstkostenpreis
            // 
            this.gb_r_selbstkostenpreis.Controls.Add(this.tb_r_gewinn);
            this.gb_r_selbstkostenpreis.Controls.Add(this.label43);
            this.gb_r_selbstkostenpreis.Controls.Add(this.tb_r_barverkaufspreis_2);
            this.gb_r_selbstkostenpreis.Controls.Add(this.tb_r_gewinnsatz);
            this.gb_r_selbstkostenpreis.Controls.Add(this.lbl_r_gewinn);
            this.gb_r_selbstkostenpreis.Controls.Add(this.lbl_r_selbstkostenpreis);
            this.gb_r_selbstkostenpreis.Controls.Add(this.lbl_r_gewinnsatz);
            this.gb_r_selbstkostenpreis.Controls.Add(this.lbl_r_barverkaufspreis_2);
            this.gb_r_selbstkostenpreis.Controls.Add(this.tb_r_selbstkostenpreis);
            this.gb_r_selbstkostenpreis.Location = new System.Drawing.Point(380, 460);
            this.gb_r_selbstkostenpreis.Name = "gb_r_selbstkostenpreis";
            this.gb_r_selbstkostenpreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_selbstkostenpreis.TabIndex = 13;
            this.gb_r_selbstkostenpreis.TabStop = false;
            this.gb_r_selbstkostenpreis.Text = "Selbstkostenpreis";
            // 
            // tb_r_gewinn
            // 
            this.tb_r_gewinn.Enabled = false;
            this.tb_r_gewinn.Location = new System.Drawing.Point(220, 60);
            this.tb_r_gewinn.Name = "tb_r_gewinn";
            this.tb_r_gewinn.Size = new System.Drawing.Size(40, 20);
            this.tb_r_gewinn.TabIndex = 11;
            this.tb_r_gewinn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(280, 20);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(63, 13);
            this.label43.TabIndex = 10;
            this.label43.Text = "auf Hundert";
            // 
            // tb_r_barverkaufspreis_2
            // 
            this.tb_r_barverkaufspreis_2.Enabled = false;
            this.tb_r_barverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_barverkaufspreis_2.Name = "tb_r_barverkaufspreis_2";
            this.tb_r_barverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_barverkaufspreis_2.TabIndex = 1;
            this.tb_r_barverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_gewinnsatz
            // 
            this.tb_r_gewinnsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_gewinnsatz.Name = "tb_r_gewinnsatz";
            this.tb_r_gewinnsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_gewinnsatz.TabIndex = 4;
            this.tb_r_gewinnsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_gewinn
            // 
            this.lbl_r_gewinn.AutoSize = true;
            this.lbl_r_gewinn.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_gewinn.Name = "lbl_r_gewinn";
            this.lbl_r_gewinn.Size = new System.Drawing.Size(49, 13);
            this.lbl_r_gewinn.TabIndex = 5;
            this.lbl_r_gewinn.Text = "- Gewinn";
            // 
            // lbl_r_selbstkostenpreis
            // 
            this.lbl_r_selbstkostenpreis.AutoSize = true;
            this.lbl_r_selbstkostenpreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_selbstkostenpreis.Name = "lbl_r_selbstkostenpreis";
            this.lbl_r_selbstkostenpreis.Size = new System.Drawing.Size(99, 13);
            this.lbl_r_selbstkostenpreis.TabIndex = 2;
            this.lbl_r_selbstkostenpreis.Text = "= Selbstkostenpreis";
            // 
            // lbl_r_gewinnsatz
            // 
            this.lbl_r_gewinnsatz.AutoSize = true;
            this.lbl_r_gewinnsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_gewinnsatz.Name = "lbl_r_gewinnsatz";
            this.lbl_r_gewinnsatz.Size = new System.Drawing.Size(62, 13);
            this.lbl_r_gewinnsatz.TabIndex = 3;
            this.lbl_r_gewinnsatz.Text = "Gewinnsatz";
            // 
            // lbl_r_barverkaufspreis_2
            // 
            this.lbl_r_barverkaufspreis_2.AutoSize = true;
            this.lbl_r_barverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_barverkaufspreis_2.Name = "lbl_r_barverkaufspreis_2";
            this.lbl_r_barverkaufspreis_2.Size = new System.Drawing.Size(86, 13);
            this.lbl_r_barverkaufspreis_2.TabIndex = 6;
            this.lbl_r_barverkaufspreis_2.Text = "Barverkaufspreis";
            // 
            // tb_r_selbstkostenpreis
            // 
            this.tb_r_selbstkostenpreis.Enabled = false;
            this.tb_r_selbstkostenpreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_selbstkostenpreis.Name = "tb_r_selbstkostenpreis";
            this.tb_r_selbstkostenpreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_selbstkostenpreis.TabIndex = 8;
            this.tb_r_selbstkostenpreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_einstandspreis
            // 
            this.gb_r_einstandspreis.Controls.Add(this.tb_r_handlungskosten);
            this.gb_r_einstandspreis.Controls.Add(this.label44);
            this.gb_r_einstandspreis.Controls.Add(this.tb_r_selbstkostenpreis_2);
            this.gb_r_einstandspreis.Controls.Add(this.tb_r_handlungskostensatz);
            this.gb_r_einstandspreis.Controls.Add(this.lbl_r_handlungskosten);
            this.gb_r_einstandspreis.Controls.Add(this.lbl_r_selbstkostenpreis_2);
            this.gb_r_einstandspreis.Controls.Add(this.lbl_r_einstandspreis);
            this.gb_r_einstandspreis.Controls.Add(this.lbl_r_handlungskostensatz);
            this.gb_r_einstandspreis.Controls.Add(this.tb_r_einstandspreis);
            this.gb_r_einstandspreis.Location = new System.Drawing.Point(380, 340);
            this.gb_r_einstandspreis.Name = "gb_r_einstandspreis";
            this.gb_r_einstandspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_einstandspreis.TabIndex = 14;
            this.gb_r_einstandspreis.TabStop = false;
            this.gb_r_einstandspreis.Text = "Einstandspreis";
            // 
            // tb_r_handlungskosten
            // 
            this.tb_r_handlungskosten.Enabled = false;
            this.tb_r_handlungskosten.Location = new System.Drawing.Point(220, 60);
            this.tb_r_handlungskosten.Name = "tb_r_handlungskosten";
            this.tb_r_handlungskosten.Size = new System.Drawing.Size(40, 20);
            this.tb_r_handlungskosten.TabIndex = 11;
            this.tb_r_handlungskosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(280, 20);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(63, 13);
            this.label44.TabIndex = 10;
            this.label44.Text = "auf Hundert";
            // 
            // tb_r_selbstkostenpreis_2
            // 
            this.tb_r_selbstkostenpreis_2.Enabled = false;
            this.tb_r_selbstkostenpreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_selbstkostenpreis_2.Name = "tb_r_selbstkostenpreis_2";
            this.tb_r_selbstkostenpreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_selbstkostenpreis_2.TabIndex = 1;
            this.tb_r_selbstkostenpreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_handlungskostensatz
            // 
            this.tb_r_handlungskostensatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_handlungskostensatz.Name = "tb_r_handlungskostensatz";
            this.tb_r_handlungskostensatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_handlungskostensatz.TabIndex = 4;
            this.tb_r_handlungskostensatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_handlungskosten
            // 
            this.lbl_r_handlungskosten.AutoSize = true;
            this.lbl_r_handlungskosten.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_handlungskosten.Name = "lbl_r_handlungskosten";
            this.lbl_r_handlungskosten.Size = new System.Drawing.Size(96, 13);
            this.lbl_r_handlungskosten.TabIndex = 5;
            this.lbl_r_handlungskosten.Text = "- Handlungskosten";
            // 
            // lbl_r_selbstkostenpreis_2
            // 
            this.lbl_r_selbstkostenpreis_2.AutoSize = true;
            this.lbl_r_selbstkostenpreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_selbstkostenpreis_2.Name = "lbl_r_selbstkostenpreis_2";
            this.lbl_r_selbstkostenpreis_2.Size = new System.Drawing.Size(90, 13);
            this.lbl_r_selbstkostenpreis_2.TabIndex = 6;
            this.lbl_r_selbstkostenpreis_2.Text = "Selbstkostenpreis";
            // 
            // lbl_r_einstandspreis
            // 
            this.lbl_r_einstandspreis.AutoSize = true;
            this.lbl_r_einstandspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_einstandspreis.Name = "lbl_r_einstandspreis";
            this.lbl_r_einstandspreis.Size = new System.Drawing.Size(84, 13);
            this.lbl_r_einstandspreis.TabIndex = 2;
            this.lbl_r_einstandspreis.Text = "= Einstandspreis";
            // 
            // lbl_r_handlungskostensatz
            // 
            this.lbl_r_handlungskostensatz.AutoSize = true;
            this.lbl_r_handlungskostensatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_handlungskostensatz.Name = "lbl_r_handlungskostensatz";
            this.lbl_r_handlungskostensatz.Size = new System.Drawing.Size(109, 13);
            this.lbl_r_handlungskostensatz.TabIndex = 3;
            this.lbl_r_handlungskostensatz.Text = "Handlungskostensatz";
            // 
            // tb_r_einstandspreis
            // 
            this.tb_r_einstandspreis.Enabled = false;
            this.tb_r_einstandspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_einstandspreis.Name = "tb_r_einstandspreis";
            this.tb_r_einstandspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_einstandspreis.TabIndex = 8;
            this.tb_r_einstandspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_bareinkaufspreis
            // 
            this.gb_r_bareinkaufspreis.Controls.Add(this.label45);
            this.gb_r_bareinkaufspreis.Controls.Add(this.tb_r_einstandspreis_2);
            this.gb_r_bareinkaufspreis.Controls.Add(this.tb_r_bezugskosten);
            this.gb_r_bareinkaufspreis.Controls.Add(this.lbl_r_einstandspreis_2);
            this.gb_r_bareinkaufspreis.Controls.Add(this.lbl_r_bareinkaufspreis);
            this.gb_r_bareinkaufspreis.Controls.Add(this.lbl_r_bezugskosten);
            this.gb_r_bareinkaufspreis.Controls.Add(this.tb_r_bareinkaufspreis);
            this.gb_r_bareinkaufspreis.Location = new System.Drawing.Point(380, 240);
            this.gb_r_bareinkaufspreis.Name = "gb_r_bareinkaufspreis";
            this.gb_r_bareinkaufspreis.Size = new System.Drawing.Size(360, 100);
            this.gb_r_bareinkaufspreis.TabIndex = 12;
            this.gb_r_bareinkaufspreis.TabStop = false;
            this.gb_r_bareinkaufspreis.Text = "Bareinkaufspreis";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(280, 20);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 13);
            this.label45.TabIndex = 10;
            this.label45.Text = "absolut";
            // 
            // tb_r_einstandspreis_2
            // 
            this.tb_r_einstandspreis_2.Enabled = false;
            this.tb_r_einstandspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_einstandspreis_2.Name = "tb_r_einstandspreis_2";
            this.tb_r_einstandspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_einstandspreis_2.TabIndex = 1;
            this.tb_r_einstandspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_bezugskosten
            // 
            this.tb_r_bezugskosten.Location = new System.Drawing.Point(220, 40);
            this.tb_r_bezugskosten.Name = "tb_r_bezugskosten";
            this.tb_r_bezugskosten.Size = new System.Drawing.Size(40, 20);
            this.tb_r_bezugskosten.TabIndex = 4;
            this.tb_r_bezugskosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_einstandspreis_2
            // 
            this.lbl_r_einstandspreis_2.AutoSize = true;
            this.lbl_r_einstandspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_einstandspreis_2.Name = "lbl_r_einstandspreis_2";
            this.lbl_r_einstandspreis_2.Size = new System.Drawing.Size(75, 13);
            this.lbl_r_einstandspreis_2.TabIndex = 6;
            this.lbl_r_einstandspreis_2.Text = "Einstandspreis";
            // 
            // lbl_r_bareinkaufspreis
            // 
            this.lbl_r_bareinkaufspreis.AutoSize = true;
            this.lbl_r_bareinkaufspreis.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_bareinkaufspreis.Name = "lbl_r_bareinkaufspreis";
            this.lbl_r_bareinkaufspreis.Size = new System.Drawing.Size(94, 13);
            this.lbl_r_bareinkaufspreis.TabIndex = 2;
            this.lbl_r_bareinkaufspreis.Text = "= Bareinkaufspreis";
            // 
            // lbl_r_bezugskosten
            // 
            this.lbl_r_bezugskosten.AutoSize = true;
            this.lbl_r_bezugskosten.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_bezugskosten.Name = "lbl_r_bezugskosten";
            this.lbl_r_bezugskosten.Size = new System.Drawing.Size(80, 13);
            this.lbl_r_bezugskosten.TabIndex = 3;
            this.lbl_r_bezugskosten.Text = "- Bezugskosten";
            // 
            // tb_r_bareinkaufspreis
            // 
            this.tb_r_bareinkaufspreis.Enabled = false;
            this.tb_r_bareinkaufspreis.Location = new System.Drawing.Point(160, 60);
            this.tb_r_bareinkaufspreis.Name = "tb_r_bareinkaufspreis";
            this.tb_r_bareinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_bareinkaufspreis.TabIndex = 8;
            this.tb_r_bareinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_zieleinkaufspreis
            // 
            this.gb_r_zieleinkaufspreis.Controls.Add(this.label46);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.tb_r_lieferskonto);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.tb_r_bareinkaufspreis_2);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.tb_r_lieferskontosatz);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.lbl_r_lieferskonto);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.lbl_r_bareinkaufspreis_2);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.lbl_r_zieleinkaufspreis);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.lbl_r_lieferskontosatz);
            this.gb_r_zieleinkaufspreis.Controls.Add(this.tb_r_zieleinkaufspreis);
            this.gb_r_zieleinkaufspreis.Location = new System.Drawing.Point(380, 120);
            this.gb_r_zieleinkaufspreis.Name = "gb_r_zieleinkaufspreis";
            this.gb_r_zieleinkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_zieleinkaufspreis.TabIndex = 12;
            this.gb_r_zieleinkaufspreis.TabStop = false;
            this.gb_r_zieleinkaufspreis.Text = "Zieleinkaufspreis";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(280, 20);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(56, 13);
            this.label46.TabIndex = 19;
            this.label46.Text = "in Hundert";
            // 
            // tb_r_lieferskonto
            // 
            this.tb_r_lieferskonto.Enabled = false;
            this.tb_r_lieferskonto.Location = new System.Drawing.Point(220, 60);
            this.tb_r_lieferskonto.Name = "tb_r_lieferskonto";
            this.tb_r_lieferskonto.Size = new System.Drawing.Size(40, 20);
            this.tb_r_lieferskonto.TabIndex = 11;
            this.tb_r_lieferskonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_bareinkaufspreis_2
            // 
            this.tb_r_bareinkaufspreis_2.Enabled = false;
            this.tb_r_bareinkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_bareinkaufspreis_2.Name = "tb_r_bareinkaufspreis_2";
            this.tb_r_bareinkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_bareinkaufspreis_2.TabIndex = 1;
            this.tb_r_bareinkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_lieferskontosatz
            // 
            this.tb_r_lieferskontosatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_lieferskontosatz.Name = "tb_r_lieferskontosatz";
            this.tb_r_lieferskontosatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_lieferskontosatz.TabIndex = 4;
            this.tb_r_lieferskontosatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_lieferskonto
            // 
            this.lbl_r_lieferskonto.AutoSize = true;
            this.lbl_r_lieferskonto.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_lieferskonto.Name = "lbl_r_lieferskonto";
            this.lbl_r_lieferskonto.Size = new System.Drawing.Size(74, 13);
            this.lbl_r_lieferskonto.TabIndex = 5;
            this.lbl_r_lieferskonto.Text = "+ Lieferskonto";
            // 
            // lbl_r_bareinkaufspreis_2
            // 
            this.lbl_r_bareinkaufspreis_2.AutoSize = true;
            this.lbl_r_bareinkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_bareinkaufspreis_2.Name = "lbl_r_bareinkaufspreis_2";
            this.lbl_r_bareinkaufspreis_2.Size = new System.Drawing.Size(85, 13);
            this.lbl_r_bareinkaufspreis_2.TabIndex = 6;
            this.lbl_r_bareinkaufspreis_2.Text = "Bareinkaufspreis";
            // 
            // lbl_r_zieleinkaufspreis
            // 
            this.lbl_r_zieleinkaufspreis.AutoSize = true;
            this.lbl_r_zieleinkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_zieleinkaufspreis.Name = "lbl_r_zieleinkaufspreis";
            this.lbl_r_zieleinkaufspreis.Size = new System.Drawing.Size(95, 13);
            this.lbl_r_zieleinkaufspreis.TabIndex = 2;
            this.lbl_r_zieleinkaufspreis.Text = "= Zieleinkaufspreis";
            // 
            // lbl_r_lieferskontosatz
            // 
            this.lbl_r_lieferskontosatz.AutoSize = true;
            this.lbl_r_lieferskontosatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_lieferskontosatz.Name = "lbl_r_lieferskontosatz";
            this.lbl_r_lieferskontosatz.Size = new System.Drawing.Size(84, 13);
            this.lbl_r_lieferskontosatz.TabIndex = 3;
            this.lbl_r_lieferskontosatz.Text = "Lieferskontosatz";
            // 
            // tb_r_zieleinkaufspreis
            // 
            this.tb_r_zieleinkaufspreis.Enabled = false;
            this.tb_r_zieleinkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_zieleinkaufspreis.Name = "tb_r_zieleinkaufspreis";
            this.tb_r_zieleinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_zieleinkaufspreis.TabIndex = 8;
            this.tb_r_zieleinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_r_nettolisteneinkaufspreis
            // 
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.label47);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.tb_r_lieferantenrabatt);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.tb_r_zieleinkaufspreis_2);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.tb_r_lieferantenrabattsatz);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.lbl_r_lieferantenrabatt);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.lbl_r_nettolisteneinkaufspreis);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.lbl_r_lieferantenrabattsatz);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.lbl_r_zieleinkaufspreis_2);
            this.gb_r_nettolisteneinkaufspreis.Controls.Add(this.tb_r_nettolisteneinkaufspreis);
            this.gb_r_nettolisteneinkaufspreis.Location = new System.Drawing.Point(380, 0);
            this.gb_r_nettolisteneinkaufspreis.Name = "gb_r_nettolisteneinkaufspreis";
            this.gb_r_nettolisteneinkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_r_nettolisteneinkaufspreis.TabIndex = 11;
            this.gb_r_nettolisteneinkaufspreis.TabStop = false;
            this.gb_r_nettolisteneinkaufspreis.Text = "Nettolisteneinkaufspreis";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(280, 20);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(56, 13);
            this.label47.TabIndex = 20;
            this.label47.Text = "in Hundert";
            // 
            // tb_r_lieferantenrabatt
            // 
            this.tb_r_lieferantenrabatt.Enabled = false;
            this.tb_r_lieferantenrabatt.Location = new System.Drawing.Point(220, 60);
            this.tb_r_lieferantenrabatt.Name = "tb_r_lieferantenrabatt";
            this.tb_r_lieferantenrabatt.Size = new System.Drawing.Size(40, 20);
            this.tb_r_lieferantenrabatt.TabIndex = 10;
            this.tb_r_lieferantenrabatt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_zieleinkaufspreis_2
            // 
            this.tb_r_zieleinkaufspreis_2.Enabled = false;
            this.tb_r_zieleinkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_r_zieleinkaufspreis_2.Name = "tb_r_zieleinkaufspreis_2";
            this.tb_r_zieleinkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_r_zieleinkaufspreis_2.TabIndex = 1;
            this.tb_r_zieleinkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_r_lieferantenrabattsatz
            // 
            this.tb_r_lieferantenrabattsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_r_lieferantenrabattsatz.Name = "tb_r_lieferantenrabattsatz";
            this.tb_r_lieferantenrabattsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_r_lieferantenrabattsatz.TabIndex = 4;
            this.tb_r_lieferantenrabattsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_r_lieferantenrabatt
            // 
            this.lbl_r_lieferantenrabatt.AutoSize = true;
            this.lbl_r_lieferantenrabatt.Location = new System.Drawing.Point(20, 60);
            this.lbl_r_lieferantenrabatt.Name = "lbl_r_lieferantenrabatt";
            this.lbl_r_lieferantenrabatt.Size = new System.Drawing.Size(96, 13);
            this.lbl_r_lieferantenrabatt.TabIndex = 5;
            this.lbl_r_lieferantenrabatt.Text = "+ Lieferantenrabatt";
            // 
            // lbl_r_nettolisteneinkaufspreis
            // 
            this.lbl_r_nettolisteneinkaufspreis.AutoSize = true;
            this.lbl_r_nettolisteneinkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_r_nettolisteneinkaufspreis.Name = "lbl_r_nettolisteneinkaufspreis";
            this.lbl_r_nettolisteneinkaufspreis.Size = new System.Drawing.Size(128, 13);
            this.lbl_r_nettolisteneinkaufspreis.TabIndex = 2;
            this.lbl_r_nettolisteneinkaufspreis.Text = "= Nettolisteneinkaufspreis";
            // 
            // lbl_r_lieferantenrabattsatz
            // 
            this.lbl_r_lieferantenrabattsatz.AutoSize = true;
            this.lbl_r_lieferantenrabattsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_r_lieferantenrabattsatz.Name = "lbl_r_lieferantenrabattsatz";
            this.lbl_r_lieferantenrabattsatz.Size = new System.Drawing.Size(106, 13);
            this.lbl_r_lieferantenrabattsatz.TabIndex = 3;
            this.lbl_r_lieferantenrabattsatz.Text = "Lieferantenrabattsatz";
            // 
            // lbl_r_zieleinkaufspreis_2
            // 
            this.lbl_r_zieleinkaufspreis_2.AutoSize = true;
            this.lbl_r_zieleinkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_r_zieleinkaufspreis_2.Name = "lbl_r_zieleinkaufspreis_2";
            this.lbl_r_zieleinkaufspreis_2.Size = new System.Drawing.Size(86, 13);
            this.lbl_r_zieleinkaufspreis_2.TabIndex = 6;
            this.lbl_r_zieleinkaufspreis_2.Text = "Zieleinkaufspreis";
            // 
            // tb_r_nettolisteneinkaufspreis
            // 
            this.tb_r_nettolisteneinkaufspreis.Enabled = false;
            this.tb_r_nettolisteneinkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_r_nettolisteneinkaufspreis.Name = "tb_r_nettolisteneinkaufspreis";
            this.tb_r_nettolisteneinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_r_nettolisteneinkaufspreis.TabIndex = 8;
            this.tb_r_nettolisteneinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_zieleinkaufspreis
            // 
            this.gb_d_zieleinkaufspreis.Controls.Add(this.label48);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.tb_d_lieferantenrabatt);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.tb_d_nettolisteneinkaufspreis);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.tb_d_lieferantenrabattsatz);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.lbl_d_lieferantenrabatt);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.lbl_d_nettolisteneinkaufspreis);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.lbl_d_lieferantenrabattsatz);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.lbl_d_zieleinkaufspreis);
            this.gb_d_zieleinkaufspreis.Controls.Add(this.tb_d_zieleinkaufspreis);
            this.gb_d_zieleinkaufspreis.Location = new System.Drawing.Point(760, 0);
            this.gb_d_zieleinkaufspreis.Name = "gb_d_zieleinkaufspreis";
            this.gb_d_zieleinkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_d_zieleinkaufspreis.TabIndex = 11;
            this.gb_d_zieleinkaufspreis.TabStop = false;
            this.gb_d_zieleinkaufspreis.Text = "Zieleinkaufspreis";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(280, 20);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(66, 13);
            this.label48.TabIndex = 20;
            this.label48.Text = "von Hundert";
            // 
            // tb_d_lieferantenrabatt
            // 
            this.tb_d_lieferantenrabatt.Enabled = false;
            this.tb_d_lieferantenrabatt.Location = new System.Drawing.Point(220, 60);
            this.tb_d_lieferantenrabatt.Name = "tb_d_lieferantenrabatt";
            this.tb_d_lieferantenrabatt.Size = new System.Drawing.Size(40, 20);
            this.tb_d_lieferantenrabatt.TabIndex = 10;
            this.tb_d_lieferantenrabatt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_nettolisteneinkaufspreis
            // 
            this.tb_d_nettolisteneinkaufspreis.Location = new System.Drawing.Point(160, 20);
            this.tb_d_nettolisteneinkaufspreis.Name = "tb_d_nettolisteneinkaufspreis";
            this.tb_d_nettolisteneinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_nettolisteneinkaufspreis.TabIndex = 1;
            this.tb_d_nettolisteneinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_lieferantenrabattsatz
            // 
            this.tb_d_lieferantenrabattsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_d_lieferantenrabattsatz.Name = "tb_d_lieferantenrabattsatz";
            this.tb_d_lieferantenrabattsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_lieferantenrabattsatz.TabIndex = 4;
            this.tb_d_lieferantenrabattsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_lieferantenrabatt
            // 
            this.lbl_d_lieferantenrabatt.AutoSize = true;
            this.lbl_d_lieferantenrabatt.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_lieferantenrabatt.Name = "lbl_d_lieferantenrabatt";
            this.lbl_d_lieferantenrabatt.Size = new System.Drawing.Size(93, 13);
            this.lbl_d_lieferantenrabatt.TabIndex = 5;
            this.lbl_d_lieferantenrabatt.Text = "- Lieferantenrabatt";
            // 
            // lbl_d_nettolisteneinkaufspreis
            // 
            this.lbl_d_nettolisteneinkaufspreis.AutoSize = true;
            this.lbl_d_nettolisteneinkaufspreis.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_nettolisteneinkaufspreis.Name = "lbl_d_nettolisteneinkaufspreis";
            this.lbl_d_nettolisteneinkaufspreis.Size = new System.Drawing.Size(119, 13);
            this.lbl_d_nettolisteneinkaufspreis.TabIndex = 2;
            this.lbl_d_nettolisteneinkaufspreis.Text = "Nettolisteneinkaufspreis";
            // 
            // lbl_d_lieferantenrabattsatz
            // 
            this.lbl_d_lieferantenrabattsatz.AutoSize = true;
            this.lbl_d_lieferantenrabattsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_lieferantenrabattsatz.Name = "lbl_d_lieferantenrabattsatz";
            this.lbl_d_lieferantenrabattsatz.Size = new System.Drawing.Size(106, 13);
            this.lbl_d_lieferantenrabattsatz.TabIndex = 3;
            this.lbl_d_lieferantenrabattsatz.Text = "Lieferantenrabattsatz";
            // 
            // lbl_d_zieleinkaufspreis
            // 
            this.lbl_d_zieleinkaufspreis.AutoSize = true;
            this.lbl_d_zieleinkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_zieleinkaufspreis.Name = "lbl_d_zieleinkaufspreis";
            this.lbl_d_zieleinkaufspreis.Size = new System.Drawing.Size(95, 13);
            this.lbl_d_zieleinkaufspreis.TabIndex = 6;
            this.lbl_d_zieleinkaufspreis.Text = "= Zieleinkaufspreis";
            // 
            // tb_d_zieleinkaufspreis
            // 
            this.tb_d_zieleinkaufspreis.Enabled = false;
            this.tb_d_zieleinkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_d_zieleinkaufspreis.Name = "tb_d_zieleinkaufspreis";
            this.tb_d_zieleinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_zieleinkaufspreis.TabIndex = 8;
            this.tb_d_zieleinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_bareinkaufspreis
            // 
            this.gb_d_bareinkaufspreis.Controls.Add(this.label49);
            this.gb_d_bareinkaufspreis.Controls.Add(this.tb_d_lieferskonto);
            this.gb_d_bareinkaufspreis.Controls.Add(this.tb_d_zieleinkaufspreis_2);
            this.gb_d_bareinkaufspreis.Controls.Add(this.tb_d_lieferskontosatz);
            this.gb_d_bareinkaufspreis.Controls.Add(this.lbl_d_lieferskonto);
            this.gb_d_bareinkaufspreis.Controls.Add(this.lbl_d_zieleinkaufspreis_2);
            this.gb_d_bareinkaufspreis.Controls.Add(this.lbl_d_lieferskontosatz);
            this.gb_d_bareinkaufspreis.Controls.Add(this.lbl_d_bareinkaufspreis);
            this.gb_d_bareinkaufspreis.Controls.Add(this.tb_d_bareinkaufspreis);
            this.gb_d_bareinkaufspreis.Location = new System.Drawing.Point(760, 120);
            this.gb_d_bareinkaufspreis.Name = "gb_d_bareinkaufspreis";
            this.gb_d_bareinkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_d_bareinkaufspreis.TabIndex = 12;
            this.gb_d_bareinkaufspreis.TabStop = false;
            this.gb_d_bareinkaufspreis.Text = "Bareinkaufspreis";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(280, 20);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(66, 13);
            this.label49.TabIndex = 21;
            this.label49.Text = "von Hundert";
            // 
            // tb_d_lieferskonto
            // 
            this.tb_d_lieferskonto.Enabled = false;
            this.tb_d_lieferskonto.Location = new System.Drawing.Point(220, 60);
            this.tb_d_lieferskonto.Name = "tb_d_lieferskonto";
            this.tb_d_lieferskonto.Size = new System.Drawing.Size(40, 20);
            this.tb_d_lieferskonto.TabIndex = 11;
            this.tb_d_lieferskonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_zieleinkaufspreis_2
            // 
            this.tb_d_zieleinkaufspreis_2.Enabled = false;
            this.tb_d_zieleinkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_d_zieleinkaufspreis_2.Name = "tb_d_zieleinkaufspreis_2";
            this.tb_d_zieleinkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_d_zieleinkaufspreis_2.TabIndex = 1;
            this.tb_d_zieleinkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_lieferskontosatz
            // 
            this.tb_d_lieferskontosatz.Location = new System.Drawing.Point(220, 40);
            this.tb_d_lieferskontosatz.Name = "tb_d_lieferskontosatz";
            this.tb_d_lieferskontosatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_lieferskontosatz.TabIndex = 4;
            this.tb_d_lieferskontosatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_lieferskonto
            // 
            this.lbl_d_lieferskonto.AutoSize = true;
            this.lbl_d_lieferskonto.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_lieferskonto.Name = "lbl_d_lieferskonto";
            this.lbl_d_lieferskonto.Size = new System.Drawing.Size(71, 13);
            this.lbl_d_lieferskonto.TabIndex = 5;
            this.lbl_d_lieferskonto.Text = "- Lieferskonto";
            // 
            // lbl_d_zieleinkaufspreis_2
            // 
            this.lbl_d_zieleinkaufspreis_2.AutoSize = true;
            this.lbl_d_zieleinkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_zieleinkaufspreis_2.Name = "lbl_d_zieleinkaufspreis_2";
            this.lbl_d_zieleinkaufspreis_2.Size = new System.Drawing.Size(86, 13);
            this.lbl_d_zieleinkaufspreis_2.TabIndex = 2;
            this.lbl_d_zieleinkaufspreis_2.Text = "Zieleinkaufspreis";
            // 
            // lbl_d_lieferskontosatz
            // 
            this.lbl_d_lieferskontosatz.AutoSize = true;
            this.lbl_d_lieferskontosatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_lieferskontosatz.Name = "lbl_d_lieferskontosatz";
            this.lbl_d_lieferskontosatz.Size = new System.Drawing.Size(84, 13);
            this.lbl_d_lieferskontosatz.TabIndex = 3;
            this.lbl_d_lieferskontosatz.Text = "Lieferskontosatz";
            // 
            // lbl_d_bareinkaufspreis
            // 
            this.lbl_d_bareinkaufspreis.AutoSize = true;
            this.lbl_d_bareinkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_bareinkaufspreis.Name = "lbl_d_bareinkaufspreis";
            this.lbl_d_bareinkaufspreis.Size = new System.Drawing.Size(94, 13);
            this.lbl_d_bareinkaufspreis.TabIndex = 6;
            this.lbl_d_bareinkaufspreis.Text = "= Bareinkaufspreis";
            // 
            // tb_d_bareinkaufspreis
            // 
            this.tb_d_bareinkaufspreis.Enabled = false;
            this.tb_d_bareinkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_d_bareinkaufspreis.Name = "tb_d_bareinkaufspreis";
            this.tb_d_bareinkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_bareinkaufspreis.TabIndex = 8;
            this.tb_d_bareinkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_einstandspreis
            // 
            this.gb_d_einstandspreis.Controls.Add(this.label56);
            this.gb_d_einstandspreis.Controls.Add(this.tb_d_bareinkaufspreis_2);
            this.gb_d_einstandspreis.Controls.Add(this.tb_d_bezugskosten);
            this.gb_d_einstandspreis.Controls.Add(this.lbl_d_bareinkaufspreis_2);
            this.gb_d_einstandspreis.Controls.Add(this.lbl_d_bezugskosten);
            this.gb_d_einstandspreis.Controls.Add(this.lbl_d_einstandspreis);
            this.gb_d_einstandspreis.Controls.Add(this.tb_d_einstandspreis);
            this.gb_d_einstandspreis.Location = new System.Drawing.Point(760, 240);
            this.gb_d_einstandspreis.Name = "gb_d_einstandspreis";
            this.gb_d_einstandspreis.Size = new System.Drawing.Size(360, 100);
            this.gb_d_einstandspreis.TabIndex = 12;
            this.gb_d_einstandspreis.TabStop = false;
            this.gb_d_einstandspreis.Text = "Einstandspreis";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(280, 20);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(41, 13);
            this.label56.TabIndex = 10;
            this.label56.Text = "absolut";
            // 
            // tb_d_bareinkaufspreis_2
            // 
            this.tb_d_bareinkaufspreis_2.Enabled = false;
            this.tb_d_bareinkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_d_bareinkaufspreis_2.Name = "tb_d_bareinkaufspreis_2";
            this.tb_d_bareinkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_d_bareinkaufspreis_2.TabIndex = 1;
            this.tb_d_bareinkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_bezugskosten
            // 
            this.tb_d_bezugskosten.Location = new System.Drawing.Point(220, 40);
            this.tb_d_bezugskosten.Name = "tb_d_bezugskosten";
            this.tb_d_bezugskosten.Size = new System.Drawing.Size(40, 20);
            this.tb_d_bezugskosten.TabIndex = 4;
            this.tb_d_bezugskosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_bareinkaufspreis_2
            // 
            this.lbl_d_bareinkaufspreis_2.AutoSize = true;
            this.lbl_d_bareinkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_bareinkaufspreis_2.Name = "lbl_d_bareinkaufspreis_2";
            this.lbl_d_bareinkaufspreis_2.Size = new System.Drawing.Size(85, 13);
            this.lbl_d_bareinkaufspreis_2.TabIndex = 2;
            this.lbl_d_bareinkaufspreis_2.Text = "Bareinkaufspreis";
            // 
            // lbl_d_bezugskosten
            // 
            this.lbl_d_bezugskosten.AutoSize = true;
            this.lbl_d_bezugskosten.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_bezugskosten.Name = "lbl_d_bezugskosten";
            this.lbl_d_bezugskosten.Size = new System.Drawing.Size(83, 13);
            this.lbl_d_bezugskosten.TabIndex = 3;
            this.lbl_d_bezugskosten.Text = "+ Bezugskosten";
            // 
            // lbl_d_einstandspreis
            // 
            this.lbl_d_einstandspreis.AutoSize = true;
            this.lbl_d_einstandspreis.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_einstandspreis.Name = "lbl_d_einstandspreis";
            this.lbl_d_einstandspreis.Size = new System.Drawing.Size(84, 13);
            this.lbl_d_einstandspreis.TabIndex = 6;
            this.lbl_d_einstandspreis.Text = "= Einstandspreis";
            // 
            // tb_d_einstandspreis
            // 
            this.tb_d_einstandspreis.Enabled = false;
            this.tb_d_einstandspreis.Location = new System.Drawing.Point(160, 60);
            this.tb_d_einstandspreis.Name = "tb_d_einstandspreis";
            this.tb_d_einstandspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_einstandspreis.TabIndex = 8;
            this.tb_d_einstandspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_selbstkostenpreis
            // 
            this.gb_d_selbstkostenpreis.Controls.Add(this.tb_d_handlungskosten);
            this.gb_d_selbstkostenpreis.Controls.Add(this.label60);
            this.gb_d_selbstkostenpreis.Controls.Add(this.tb_d_einstandspreis_2);
            this.gb_d_selbstkostenpreis.Controls.Add(this.tb_d_handlungskostensatz);
            this.gb_d_selbstkostenpreis.Controls.Add(this.lbl_d_handlungskosten);
            this.gb_d_selbstkostenpreis.Controls.Add(this.lbl_d_einstandspreis_2);
            this.gb_d_selbstkostenpreis.Controls.Add(this.lbl_d_handlungskostensatz);
            this.gb_d_selbstkostenpreis.Controls.Add(this.lbl_d_selbstkostenpreis);
            this.gb_d_selbstkostenpreis.Controls.Add(this.tb_d_selbstkostenpreis);
            this.gb_d_selbstkostenpreis.Location = new System.Drawing.Point(760, 340);
            this.gb_d_selbstkostenpreis.Name = "gb_d_selbstkostenpreis";
            this.gb_d_selbstkostenpreis.Size = new System.Drawing.Size(360, 120);
            this.gb_d_selbstkostenpreis.TabIndex = 14;
            this.gb_d_selbstkostenpreis.TabStop = false;
            this.gb_d_selbstkostenpreis.Text = "Selbstkostenpreis";
            // 
            // tb_d_handlungskosten
            // 
            this.tb_d_handlungskosten.Enabled = false;
            this.tb_d_handlungskosten.Location = new System.Drawing.Point(220, 60);
            this.tb_d_handlungskosten.Name = "tb_d_handlungskosten";
            this.tb_d_handlungskosten.Size = new System.Drawing.Size(40, 20);
            this.tb_d_handlungskosten.TabIndex = 11;
            this.tb_d_handlungskosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(280, 20);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(66, 13);
            this.label60.TabIndex = 10;
            this.label60.Text = "von Hundert";
            // 
            // tb_d_einstandspreis_2
            // 
            this.tb_d_einstandspreis_2.Enabled = false;
            this.tb_d_einstandspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_d_einstandspreis_2.Name = "tb_d_einstandspreis_2";
            this.tb_d_einstandspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_d_einstandspreis_2.TabIndex = 1;
            this.tb_d_einstandspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_handlungskostensatz
            // 
            this.tb_d_handlungskostensatz.Location = new System.Drawing.Point(220, 40);
            this.tb_d_handlungskostensatz.Name = "tb_d_handlungskostensatz";
            this.tb_d_handlungskostensatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_handlungskostensatz.TabIndex = 4;
            this.tb_d_handlungskostensatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_handlungskosten
            // 
            this.lbl_d_handlungskosten.AutoSize = true;
            this.lbl_d_handlungskosten.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_handlungskosten.Name = "lbl_d_handlungskosten";
            this.lbl_d_handlungskosten.Size = new System.Drawing.Size(99, 13);
            this.lbl_d_handlungskosten.TabIndex = 5;
            this.lbl_d_handlungskosten.Text = "+ Handlungskosten";
            // 
            // lbl_d_einstandspreis_2
            // 
            this.lbl_d_einstandspreis_2.AutoSize = true;
            this.lbl_d_einstandspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_einstandspreis_2.Name = "lbl_d_einstandspreis_2";
            this.lbl_d_einstandspreis_2.Size = new System.Drawing.Size(75, 13);
            this.lbl_d_einstandspreis_2.TabIndex = 2;
            this.lbl_d_einstandspreis_2.Text = "Einstandspreis";
            // 
            // lbl_d_handlungskostensatz
            // 
            this.lbl_d_handlungskostensatz.AutoSize = true;
            this.lbl_d_handlungskostensatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_handlungskostensatz.Name = "lbl_d_handlungskostensatz";
            this.lbl_d_handlungskostensatz.Size = new System.Drawing.Size(109, 13);
            this.lbl_d_handlungskostensatz.TabIndex = 3;
            this.lbl_d_handlungskostensatz.Text = "Handlungskostensatz";
            // 
            // lbl_d_selbstkostenpreis
            // 
            this.lbl_d_selbstkostenpreis.AutoSize = true;
            this.lbl_d_selbstkostenpreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_selbstkostenpreis.Name = "lbl_d_selbstkostenpreis";
            this.lbl_d_selbstkostenpreis.Size = new System.Drawing.Size(99, 13);
            this.lbl_d_selbstkostenpreis.TabIndex = 6;
            this.lbl_d_selbstkostenpreis.Text = "= Selbstkostenpreis";
            // 
            // tb_d_selbstkostenpreis
            // 
            this.tb_d_selbstkostenpreis.Enabled = false;
            this.tb_d_selbstkostenpreis.Location = new System.Drawing.Point(160, 80);
            this.tb_d_selbstkostenpreis.Name = "tb_d_selbstkostenpreis";
            this.tb_d_selbstkostenpreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_selbstkostenpreis.TabIndex = 8;
            this.tb_d_selbstkostenpreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_gewinn
            // 
            this.gb_gewinn.Controls.Add(this.tb_d_gewinnsatz);
            this.gb_gewinn.Controls.Add(this.label65);
            this.gb_gewinn.Controls.Add(this.tb_d_barverkaufspreis_2);
            this.gb_gewinn.Controls.Add(this.tb_d_selbstkostenpreis_2);
            this.gb_gewinn.Controls.Add(this.lbl_d_selbstkostenpreis_2);
            this.gb_gewinn.Controls.Add(this.lbl_d_barverkaufspreis_2);
            this.gb_gewinn.Controls.Add(this.lbl_d_gewinnsatz);
            this.gb_gewinn.Controls.Add(this.lbl_d_gewinn);
            this.gb_gewinn.Controls.Add(this.tb_d_gewinn);
            this.gb_gewinn.Location = new System.Drawing.Point(760, 460);
            this.gb_gewinn.Name = "gb_gewinn";
            this.gb_gewinn.Size = new System.Drawing.Size(360, 120);
            this.gb_gewinn.TabIndex = 13;
            this.gb_gewinn.TabStop = false;
            this.gb_gewinn.Text = "Gewinn";
            // 
            // tb_d_gewinnsatz
            // 
            this.tb_d_gewinnsatz.Enabled = false;
            this.tb_d_gewinnsatz.Location = new System.Drawing.Point(220, 80);
            this.tb_d_gewinnsatz.Name = "tb_d_gewinnsatz";
            this.tb_d_gewinnsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_gewinnsatz.TabIndex = 11;
            this.tb_d_gewinnsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(280, 20);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(66, 13);
            this.label65.TabIndex = 10;
            this.label65.Text = "von Hundert";
            // 
            // tb_d_barverkaufspreis_2
            // 
            this.tb_d_barverkaufspreis_2.Enabled = false;
            this.tb_d_barverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_d_barverkaufspreis_2.Name = "tb_d_barverkaufspreis_2";
            this.tb_d_barverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_d_barverkaufspreis_2.TabIndex = 1;
            this.tb_d_barverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_selbstkostenpreis_2
            // 
            this.tb_d_selbstkostenpreis_2.Enabled = false;
            this.tb_d_selbstkostenpreis_2.Location = new System.Drawing.Point(220, 40);
            this.tb_d_selbstkostenpreis_2.Name = "tb_d_selbstkostenpreis_2";
            this.tb_d_selbstkostenpreis_2.Size = new System.Drawing.Size(40, 20);
            this.tb_d_selbstkostenpreis_2.TabIndex = 4;
            this.tb_d_selbstkostenpreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_selbstkostenpreis_2
            // 
            this.lbl_d_selbstkostenpreis_2.AutoSize = true;
            this.lbl_d_selbstkostenpreis_2.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_selbstkostenpreis_2.Name = "lbl_d_selbstkostenpreis_2";
            this.lbl_d_selbstkostenpreis_2.Size = new System.Drawing.Size(96, 13);
            this.lbl_d_selbstkostenpreis_2.TabIndex = 5;
            this.lbl_d_selbstkostenpreis_2.Text = "- Selbstkostenpreis";
            // 
            // lbl_d_barverkaufspreis_2
            // 
            this.lbl_d_barverkaufspreis_2.AutoSize = true;
            this.lbl_d_barverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_barverkaufspreis_2.Name = "lbl_d_barverkaufspreis_2";
            this.lbl_d_barverkaufspreis_2.Size = new System.Drawing.Size(86, 13);
            this.lbl_d_barverkaufspreis_2.TabIndex = 2;
            this.lbl_d_barverkaufspreis_2.Text = "Barverkaufspreis";
            // 
            // lbl_d_gewinnsatz
            // 
            this.lbl_d_gewinnsatz.AutoSize = true;
            this.lbl_d_gewinnsatz.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_gewinnsatz.Name = "lbl_d_gewinnsatz";
            this.lbl_d_gewinnsatz.Size = new System.Drawing.Size(62, 13);
            this.lbl_d_gewinnsatz.TabIndex = 3;
            this.lbl_d_gewinnsatz.Text = "Gewinnsatz";
            // 
            // lbl_d_gewinn
            // 
            this.lbl_d_gewinn.AutoSize = true;
            this.lbl_d_gewinn.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_gewinn.Name = "lbl_d_gewinn";
            this.lbl_d_gewinn.Size = new System.Drawing.Size(52, 13);
            this.lbl_d_gewinn.TabIndex = 6;
            this.lbl_d_gewinn.Text = "= Gewinn";
            // 
            // tb_d_gewinn
            // 
            this.tb_d_gewinn.Enabled = false;
            this.tb_d_gewinn.Location = new System.Drawing.Point(160, 60);
            this.tb_d_gewinn.Name = "tb_d_gewinn";
            this.tb_d_gewinn.Size = new System.Drawing.Size(100, 20);
            this.tb_d_gewinn.TabIndex = 8;
            this.tb_d_gewinn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_barverkaufspreis
            // 
            this.gb_d_barverkaufspreis.Controls.Add(this.groupBox12);
            this.gb_d_barverkaufspreis.Controls.Add(this.tb_d_kundenskonto);
            this.gb_d_barverkaufspreis.Controls.Add(this.label75);
            this.gb_d_barverkaufspreis.Controls.Add(this.tb_d_barverkaufspreis);
            this.gb_d_barverkaufspreis.Controls.Add(this.tb_d_kundenskontosatz);
            this.gb_d_barverkaufspreis.Controls.Add(this.lbl_d_kundenskonto);
            this.gb_d_barverkaufspreis.Controls.Add(this.lbl_d_barverkaufspreis);
            this.gb_d_barverkaufspreis.Controls.Add(this.lbl_d_kundenskontosatz);
            this.gb_d_barverkaufspreis.Controls.Add(this.lbl_d_zielverkaufspreis_2);
            this.gb_d_barverkaufspreis.Controls.Add(this.tb_d_zielverkaufspreis_2);
            this.gb_d_barverkaufspreis.Location = new System.Drawing.Point(760, 580);
            this.gb_d_barverkaufspreis.Name = "gb_d_barverkaufspreis";
            this.gb_d_barverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_d_barverkaufspreis.TabIndex = 18;
            this.gb_d_barverkaufspreis.TabStop = false;
            this.gb_d_barverkaufspreis.Text = "Barverkaufspreis";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.textBox44);
            this.groupBox12.Controls.Add(this.label70);
            this.groupBox12.Controls.Add(this.textBox45);
            this.groupBox12.Controls.Add(this.textBox46);
            this.groupBox12.Controls.Add(this.label71);
            this.groupBox12.Controls.Add(this.label72);
            this.groupBox12.Controls.Add(this.label73);
            this.groupBox12.Controls.Add(this.label74);
            this.groupBox12.Controls.Add(this.textBox47);
            this.groupBox12.Location = new System.Drawing.Point(0, 140);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(280, 140);
            this.groupBox12.TabIndex = 14;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Zielverkaufspreis";
            // 
            // textBox44
            // 
            this.textBox44.Enabled = false;
            this.textBox44.Location = new System.Drawing.Point(220, 80);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(40, 20);
            this.textBox44.TabIndex = 11;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(200, 20);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(56, 13);
            this.label70.TabIndex = 10;
            this.label70.Text = "in Hundert";
            // 
            // textBox45
            // 
            this.textBox45.Enabled = false;
            this.textBox45.Location = new System.Drawing.Point(160, 40);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 20);
            this.textBox45.TabIndex = 1;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(220, 60);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(40, 20);
            this.textBox46.TabIndex = 4;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(20, 80);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(85, 13);
            this.label71.TabIndex = 5;
            this.label71.Text = "+ Kundenskonto";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(20, 40);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(86, 13);
            this.label72.TabIndex = 2;
            this.label72.Text = "Barverkaufspreis";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(20, 60);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(95, 13);
            this.label73.TabIndex = 3;
            this.label73.Text = "Kundenskontosatz";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(20, 100);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(96, 13);
            this.label74.TabIndex = 6;
            this.label74.Text = "= Zielverkaufspreis";
            // 
            // textBox47
            // 
            this.textBox47.Enabled = false;
            this.textBox47.Location = new System.Drawing.Point(160, 100);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 20);
            this.textBox47.TabIndex = 8;
            // 
            // tb_d_kundenskonto
            // 
            this.tb_d_kundenskonto.Enabled = false;
            this.tb_d_kundenskonto.Location = new System.Drawing.Point(220, 60);
            this.tb_d_kundenskonto.Name = "tb_d_kundenskonto";
            this.tb_d_kundenskonto.Size = new System.Drawing.Size(40, 20);
            this.tb_d_kundenskonto.TabIndex = 11;
            this.tb_d_kundenskonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(280, 20);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(66, 13);
            this.label75.TabIndex = 10;
            this.label75.Text = "von Hundert";
            // 
            // tb_d_barverkaufspreis
            // 
            this.tb_d_barverkaufspreis.Enabled = false;
            this.tb_d_barverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_d_barverkaufspreis.Name = "tb_d_barverkaufspreis";
            this.tb_d_barverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_barverkaufspreis.TabIndex = 1;
            this.tb_d_barverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_kundenskontosatz
            // 
            this.tb_d_kundenskontosatz.Location = new System.Drawing.Point(220, 40);
            this.tb_d_kundenskontosatz.Name = "tb_d_kundenskontosatz";
            this.tb_d_kundenskontosatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_kundenskontosatz.TabIndex = 4;
            this.tb_d_kundenskontosatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_kundenskonto
            // 
            this.lbl_d_kundenskonto.AutoSize = true;
            this.lbl_d_kundenskonto.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_kundenskonto.Name = "lbl_d_kundenskonto";
            this.lbl_d_kundenskonto.Size = new System.Drawing.Size(82, 13);
            this.lbl_d_kundenskonto.TabIndex = 5;
            this.lbl_d_kundenskonto.Text = "- Kundenskonto";
            // 
            // lbl_d_barverkaufspreis
            // 
            this.lbl_d_barverkaufspreis.AutoSize = true;
            this.lbl_d_barverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_barverkaufspreis.Name = "lbl_d_barverkaufspreis";
            this.lbl_d_barverkaufspreis.Size = new System.Drawing.Size(95, 13);
            this.lbl_d_barverkaufspreis.TabIndex = 2;
            this.lbl_d_barverkaufspreis.Text = "= Barverkaufspreis";
            // 
            // lbl_d_kundenskontosatz
            // 
            this.lbl_d_kundenskontosatz.AutoSize = true;
            this.lbl_d_kundenskontosatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_kundenskontosatz.Name = "lbl_d_kundenskontosatz";
            this.lbl_d_kundenskontosatz.Size = new System.Drawing.Size(95, 13);
            this.lbl_d_kundenskontosatz.TabIndex = 3;
            this.lbl_d_kundenskontosatz.Text = "Kundenskontosatz";
            // 
            // lbl_d_zielverkaufspreis_2
            // 
            this.lbl_d_zielverkaufspreis_2.AutoSize = true;
            this.lbl_d_zielverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_zielverkaufspreis_2.Name = "lbl_d_zielverkaufspreis_2";
            this.lbl_d_zielverkaufspreis_2.Size = new System.Drawing.Size(87, 13);
            this.lbl_d_zielverkaufspreis_2.TabIndex = 6;
            this.lbl_d_zielverkaufspreis_2.Text = "Zielverkaufspreis";
            // 
            // tb_d_zielverkaufspreis_2
            // 
            this.tb_d_zielverkaufspreis_2.Enabled = false;
            this.tb_d_zielverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_d_zielverkaufspreis_2.Name = "tb_d_zielverkaufspreis_2";
            this.tb_d_zielverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_d_zielverkaufspreis_2.TabIndex = 8;
            this.tb_d_zielverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_zielverkaufspreis
            // 
            this.gb_d_zielverkaufspreis.Controls.Add(this.groupBox14);
            this.gb_d_zielverkaufspreis.Controls.Add(this.tb_d_kundenrabatt);
            this.gb_d_zielverkaufspreis.Controls.Add(this.label85);
            this.gb_d_zielverkaufspreis.Controls.Add(this.tb_d_zielverkaufspreis);
            this.gb_d_zielverkaufspreis.Controls.Add(this.tb_d_kundenrabattsatz);
            this.gb_d_zielverkaufspreis.Controls.Add(this.lbl_d_kundenrabatt);
            this.gb_d_zielverkaufspreis.Controls.Add(this.lbl_d_zielverkaufspreis);
            this.gb_d_zielverkaufspreis.Controls.Add(this.lbl_d_kundenrabattsatz);
            this.gb_d_zielverkaufspreis.Controls.Add(this.lbl_d_nettolistenverkaufspreis_2);
            this.gb_d_zielverkaufspreis.Controls.Add(this.tb_d_nettolistenverkaufspreis_2);
            this.gb_d_zielverkaufspreis.Location = new System.Drawing.Point(760, 700);
            this.gb_d_zielverkaufspreis.Name = "gb_d_zielverkaufspreis";
            this.gb_d_zielverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_d_zielverkaufspreis.TabIndex = 17;
            this.gb_d_zielverkaufspreis.TabStop = false;
            this.gb_d_zielverkaufspreis.Text = "Zielverkaufspreis";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.textBox52);
            this.groupBox14.Controls.Add(this.label80);
            this.groupBox14.Controls.Add(this.textBox53);
            this.groupBox14.Controls.Add(this.textBox54);
            this.groupBox14.Controls.Add(this.label81);
            this.groupBox14.Controls.Add(this.label82);
            this.groupBox14.Controls.Add(this.label83);
            this.groupBox14.Controls.Add(this.label84);
            this.groupBox14.Controls.Add(this.textBox55);
            this.groupBox14.Location = new System.Drawing.Point(0, 140);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(280, 140);
            this.groupBox14.TabIndex = 14;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Zielverkaufspreis";
            // 
            // textBox52
            // 
            this.textBox52.Enabled = false;
            this.textBox52.Location = new System.Drawing.Point(220, 80);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(40, 20);
            this.textBox52.TabIndex = 11;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(200, 20);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(56, 13);
            this.label80.TabIndex = 10;
            this.label80.Text = "in Hundert";
            // 
            // textBox53
            // 
            this.textBox53.Enabled = false;
            this.textBox53.Location = new System.Drawing.Point(160, 40);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 20);
            this.textBox53.TabIndex = 1;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(220, 60);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(40, 20);
            this.textBox54.TabIndex = 4;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(20, 80);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(85, 13);
            this.label81.TabIndex = 5;
            this.label81.Text = "+ Kundenskonto";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(20, 40);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(86, 13);
            this.label82.TabIndex = 2;
            this.label82.Text = "Barverkaufspreis";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(20, 60);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(95, 13);
            this.label83.TabIndex = 3;
            this.label83.Text = "Kundenskontosatz";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(20, 100);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(96, 13);
            this.label84.TabIndex = 6;
            this.label84.Text = "= Zielverkaufspreis";
            // 
            // textBox55
            // 
            this.textBox55.Enabled = false;
            this.textBox55.Location = new System.Drawing.Point(160, 100);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 20);
            this.textBox55.TabIndex = 8;
            // 
            // tb_d_kundenrabatt
            // 
            this.tb_d_kundenrabatt.Enabled = false;
            this.tb_d_kundenrabatt.Location = new System.Drawing.Point(220, 60);
            this.tb_d_kundenrabatt.Name = "tb_d_kundenrabatt";
            this.tb_d_kundenrabatt.Size = new System.Drawing.Size(40, 20);
            this.tb_d_kundenrabatt.TabIndex = 11;
            this.tb_d_kundenrabatt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(280, 20);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(66, 13);
            this.label85.TabIndex = 10;
            this.label85.Text = "von Hundert";
            // 
            // tb_d_zielverkaufspreis
            // 
            this.tb_d_zielverkaufspreis.Enabled = false;
            this.tb_d_zielverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_d_zielverkaufspreis.Name = "tb_d_zielverkaufspreis";
            this.tb_d_zielverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_zielverkaufspreis.TabIndex = 1;
            this.tb_d_zielverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_kundenrabattsatz
            // 
            this.tb_d_kundenrabattsatz.Location = new System.Drawing.Point(220, 40);
            this.tb_d_kundenrabattsatz.Name = "tb_d_kundenrabattsatz";
            this.tb_d_kundenrabattsatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_kundenrabattsatz.TabIndex = 4;
            this.tb_d_kundenrabattsatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_kundenrabatt
            // 
            this.lbl_d_kundenrabatt.AutoSize = true;
            this.lbl_d_kundenrabatt.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_kundenrabatt.Name = "lbl_d_kundenrabatt";
            this.lbl_d_kundenrabatt.Size = new System.Drawing.Size(77, 13);
            this.lbl_d_kundenrabatt.TabIndex = 5;
            this.lbl_d_kundenrabatt.Text = "- Kundenrabatt";
            // 
            // lbl_d_zielverkaufspreis
            // 
            this.lbl_d_zielverkaufspreis.AutoSize = true;
            this.lbl_d_zielverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_zielverkaufspreis.Name = "lbl_d_zielverkaufspreis";
            this.lbl_d_zielverkaufspreis.Size = new System.Drawing.Size(96, 13);
            this.lbl_d_zielverkaufspreis.TabIndex = 2;
            this.lbl_d_zielverkaufspreis.Text = "= Zielverkaufspreis";
            // 
            // lbl_d_kundenrabattsatz
            // 
            this.lbl_d_kundenrabattsatz.AutoSize = true;
            this.lbl_d_kundenrabattsatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_kundenrabattsatz.Name = "lbl_d_kundenrabattsatz";
            this.lbl_d_kundenrabattsatz.Size = new System.Drawing.Size(90, 13);
            this.lbl_d_kundenrabattsatz.TabIndex = 3;
            this.lbl_d_kundenrabattsatz.Text = "Kundenrabattsatz";
            // 
            // lbl_d_nettolistenverkaufspreis_2
            // 
            this.lbl_d_nettolistenverkaufspreis_2.AutoSize = true;
            this.lbl_d_nettolistenverkaufspreis_2.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_nettolistenverkaufspreis_2.Name = "lbl_d_nettolistenverkaufspreis_2";
            this.lbl_d_nettolistenverkaufspreis_2.Size = new System.Drawing.Size(120, 13);
            this.lbl_d_nettolistenverkaufspreis_2.TabIndex = 6;
            this.lbl_d_nettolistenverkaufspreis_2.Text = "Nettolistenverkaufspreis";
            // 
            // tb_d_nettolistenverkaufspreis_2
            // 
            this.tb_d_nettolistenverkaufspreis_2.Enabled = false;
            this.tb_d_nettolistenverkaufspreis_2.Location = new System.Drawing.Point(160, 20);
            this.tb_d_nettolistenverkaufspreis_2.Name = "tb_d_nettolistenverkaufspreis_2";
            this.tb_d_nettolistenverkaufspreis_2.Size = new System.Drawing.Size(100, 20);
            this.tb_d_nettolistenverkaufspreis_2.TabIndex = 8;
            this.tb_d_nettolistenverkaufspreis_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_d_nettolistenverkaufspreis
            // 
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.groupBox16);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.tb_d_umsatzsteuer);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.label95);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.tb_d_nettolistenverkaufspreis);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.tb_d_umsatzsteuersatz);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.lbl_d_umsatzsteuer);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.lbl_d_nettolistenverkaufspreis);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.lbl_d_umsatzsteuersatz);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.lbl_d_bruttoverkaufspreis);
            this.gb_d_nettolistenverkaufspreis.Controls.Add(this.tb_d_bruttoverkaufspreis);
            this.gb_d_nettolistenverkaufspreis.Location = new System.Drawing.Point(760, 820);
            this.gb_d_nettolistenverkaufspreis.Name = "gb_d_nettolistenverkaufspreis";
            this.gb_d_nettolistenverkaufspreis.Size = new System.Drawing.Size(360, 120);
            this.gb_d_nettolistenverkaufspreis.TabIndex = 18;
            this.gb_d_nettolistenverkaufspreis.TabStop = false;
            this.gb_d_nettolistenverkaufspreis.Text = "Nettolistenverkaufspreis";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.textBox60);
            this.groupBox16.Controls.Add(this.label90);
            this.groupBox16.Controls.Add(this.textBox61);
            this.groupBox16.Controls.Add(this.textBox62);
            this.groupBox16.Controls.Add(this.label91);
            this.groupBox16.Controls.Add(this.label92);
            this.groupBox16.Controls.Add(this.label93);
            this.groupBox16.Controls.Add(this.label94);
            this.groupBox16.Controls.Add(this.textBox63);
            this.groupBox16.Location = new System.Drawing.Point(0, 140);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(280, 140);
            this.groupBox16.TabIndex = 14;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Zielverkaufspreis";
            // 
            // textBox60
            // 
            this.textBox60.Enabled = false;
            this.textBox60.Location = new System.Drawing.Point(220, 80);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(40, 20);
            this.textBox60.TabIndex = 11;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(200, 20);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(56, 13);
            this.label90.TabIndex = 10;
            this.label90.Text = "in Hundert";
            // 
            // textBox61
            // 
            this.textBox61.Enabled = false;
            this.textBox61.Location = new System.Drawing.Point(160, 40);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 20);
            this.textBox61.TabIndex = 1;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(220, 60);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(40, 20);
            this.textBox62.TabIndex = 4;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(20, 80);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(85, 13);
            this.label91.TabIndex = 5;
            this.label91.Text = "+ Kundenskonto";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(20, 40);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(86, 13);
            this.label92.TabIndex = 2;
            this.label92.Text = "Barverkaufspreis";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(20, 60);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(95, 13);
            this.label93.TabIndex = 3;
            this.label93.Text = "Kundenskontosatz";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(20, 100);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(96, 13);
            this.label94.TabIndex = 6;
            this.label94.Text = "= Zielverkaufspreis";
            // 
            // textBox63
            // 
            this.textBox63.Enabled = false;
            this.textBox63.Location = new System.Drawing.Point(160, 100);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(100, 20);
            this.textBox63.TabIndex = 8;
            // 
            // tb_d_umsatzsteuer
            // 
            this.tb_d_umsatzsteuer.Enabled = false;
            this.tb_d_umsatzsteuer.Location = new System.Drawing.Point(220, 60);
            this.tb_d_umsatzsteuer.Name = "tb_d_umsatzsteuer";
            this.tb_d_umsatzsteuer.Size = new System.Drawing.Size(40, 20);
            this.tb_d_umsatzsteuer.TabIndex = 11;
            this.tb_d_umsatzsteuer.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(280, 20);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(63, 13);
            this.label95.TabIndex = 10;
            this.label95.Text = "auf Hundert";
            // 
            // tb_d_nettolistenverkaufspreis
            // 
            this.tb_d_nettolistenverkaufspreis.Enabled = false;
            this.tb_d_nettolistenverkaufspreis.Location = new System.Drawing.Point(160, 80);
            this.tb_d_nettolistenverkaufspreis.Name = "tb_d_nettolistenverkaufspreis";
            this.tb_d_nettolistenverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_nettolistenverkaufspreis.TabIndex = 1;
            this.tb_d_nettolistenverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_d_umsatzsteuersatz
            // 
            this.tb_d_umsatzsteuersatz.Location = new System.Drawing.Point(220, 40);
            this.tb_d_umsatzsteuersatz.Name = "tb_d_umsatzsteuersatz";
            this.tb_d_umsatzsteuersatz.Size = new System.Drawing.Size(40, 20);
            this.tb_d_umsatzsteuersatz.TabIndex = 4;
            this.tb_d_umsatzsteuersatz.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbl_d_umsatzsteuer
            // 
            this.lbl_d_umsatzsteuer.AutoSize = true;
            this.lbl_d_umsatzsteuer.Location = new System.Drawing.Point(20, 60);
            this.lbl_d_umsatzsteuer.Name = "lbl_d_umsatzsteuer";
            this.lbl_d_umsatzsteuer.Size = new System.Drawing.Size(77, 13);
            this.lbl_d_umsatzsteuer.TabIndex = 5;
            this.lbl_d_umsatzsteuer.Text = "- Umsatzsteuer";
            // 
            // lbl_d_nettolistenverkaufspreis
            // 
            this.lbl_d_nettolistenverkaufspreis.AutoSize = true;
            this.lbl_d_nettolistenverkaufspreis.Location = new System.Drawing.Point(20, 80);
            this.lbl_d_nettolistenverkaufspreis.Name = "lbl_d_nettolistenverkaufspreis";
            this.lbl_d_nettolistenverkaufspreis.Size = new System.Drawing.Size(129, 13);
            this.lbl_d_nettolistenverkaufspreis.TabIndex = 2;
            this.lbl_d_nettolistenverkaufspreis.Text = "= Nettolistenverkaufspreis";
            // 
            // lbl_d_umsatzsteuersatz
            // 
            this.lbl_d_umsatzsteuersatz.AutoSize = true;
            this.lbl_d_umsatzsteuersatz.Location = new System.Drawing.Point(20, 40);
            this.lbl_d_umsatzsteuersatz.Name = "lbl_d_umsatzsteuersatz";
            this.lbl_d_umsatzsteuersatz.Size = new System.Drawing.Size(90, 13);
            this.lbl_d_umsatzsteuersatz.TabIndex = 3;
            this.lbl_d_umsatzsteuersatz.Text = "Umsatzsteuersatz";
            // 
            // lbl_d_bruttoverkaufspreis
            // 
            this.lbl_d_bruttoverkaufspreis.AutoSize = true;
            this.lbl_d_bruttoverkaufspreis.Location = new System.Drawing.Point(20, 20);
            this.lbl_d_bruttoverkaufspreis.Name = "lbl_d_bruttoverkaufspreis";
            this.lbl_d_bruttoverkaufspreis.Size = new System.Drawing.Size(98, 13);
            this.lbl_d_bruttoverkaufspreis.TabIndex = 6;
            this.lbl_d_bruttoverkaufspreis.Text = "Bruttoverkaufspreis";
            // 
            // tb_d_bruttoverkaufspreis
            // 
            this.tb_d_bruttoverkaufspreis.Location = new System.Drawing.Point(160, 20);
            this.tb_d_bruttoverkaufspreis.Name = "tb_d_bruttoverkaufspreis";
            this.tb_d_bruttoverkaufspreis.Size = new System.Drawing.Size(100, 20);
            this.tb_d_bruttoverkaufspreis.TabIndex = 8;
            this.tb_d_bruttoverkaufspreis.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_differenzkalkulation
            // 
            this.btn_differenzkalkulation.Location = new System.Drawing.Point(860, 960);
            this.btn_differenzkalkulation.Name = "btn_differenzkalkulation";
            this.btn_differenzkalkulation.Size = new System.Drawing.Size(160, 23);
            this.btn_differenzkalkulation.TabIndex = 19;
            this.btn_differenzkalkulation.Text = "Berechne Differenz";
            this.btn_differenzkalkulation.UseVisualStyleBackColor = true;
            this.btn_differenzkalkulation.Click += new System.EventHandler(this.btn_differenzkalkulation_Click);
            // 
            // frm_handelskalkulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1128, 995);
            this.Controls.Add(this.btn_differenzkalkulation);
            this.Controls.Add(this.gb_d_nettolistenverkaufspreis);
            this.Controls.Add(this.gb_d_zielverkaufspreis);
            this.Controls.Add(this.gb_d_barverkaufspreis);
            this.Controls.Add(this.gb_gewinn);
            this.Controls.Add(this.gb_d_selbstkostenpreis);
            this.Controls.Add(this.gb_d_einstandspreis);
            this.Controls.Add(this.gb_d_bareinkaufspreis);
            this.Controls.Add(this.gb_d_zieleinkaufspreis);
            this.Controls.Add(this.gb_r_nettolisteneinkaufspreis);
            this.Controls.Add(this.gb_r_zieleinkaufspreis);
            this.Controls.Add(this.gb_r_bareinkaufspreis);
            this.Controls.Add(this.gb_r_einstandspreis);
            this.Controls.Add(this.gb_r_selbstkostenpreis);
            this.Controls.Add(this.gb_r_barverkaufspreis);
            this.Controls.Add(this.gb_r_zielverkaufspreis);
            this.Controls.Add(this.btn_rueckwaertskalkulation);
            this.Controls.Add(this.gb_r_nettolistenverkaufspreis);
            this.Controls.Add(this.gb_bruttoverkaufspreis);
            this.Controls.Add(this.gb_nettolistenverkaufspreis);
            this.Controls.Add(this.gb_zielverkaufspreis);
            this.Controls.Add(this.gb_selbstkostenpreis);
            this.Controls.Add(this.gb_barverkaufspreis);
            this.Controls.Add(this.gb_einstandspreis);
            this.Controls.Add(this.gb_bareinkaufspreis);
            this.Controls.Add(this.btn_vorwaertskalkulation);
            this.Controls.Add(this.gb_zieleinkaufspreis);
            this.Name = "frm_handelskalkulation";
            this.Text = "Handelskalkulation";
            this.gb_zieleinkaufspreis.ResumeLayout(false);
            this.gb_zieleinkaufspreis.PerformLayout();
            this.gb_bareinkaufspreis.ResumeLayout(false);
            this.gb_bareinkaufspreis.PerformLayout();
            this.gb_einstandspreis.ResumeLayout(false);
            this.gb_einstandspreis.PerformLayout();
            this.gb_barverkaufspreis.ResumeLayout(false);
            this.gb_barverkaufspreis.PerformLayout();
            this.gb_selbstkostenpreis.ResumeLayout(false);
            this.gb_selbstkostenpreis.PerformLayout();
            this.gb_zielverkaufspreis.ResumeLayout(false);
            this.gb_zielverkaufspreis.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gb_nettolistenverkaufspreis.ResumeLayout(false);
            this.gb_nettolistenverkaufspreis.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.gb_bruttoverkaufspreis.ResumeLayout(false);
            this.gb_bruttoverkaufspreis.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.gb_r_nettolistenverkaufspreis.ResumeLayout(false);
            this.gb_r_nettolistenverkaufspreis.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.gb_r_zielverkaufspreis.ResumeLayout(false);
            this.gb_r_zielverkaufspreis.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.gb_r_barverkaufspreis.ResumeLayout(false);
            this.gb_r_barverkaufspreis.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.gb_r_selbstkostenpreis.ResumeLayout(false);
            this.gb_r_selbstkostenpreis.PerformLayout();
            this.gb_r_einstandspreis.ResumeLayout(false);
            this.gb_r_einstandspreis.PerformLayout();
            this.gb_r_bareinkaufspreis.ResumeLayout(false);
            this.gb_r_bareinkaufspreis.PerformLayout();
            this.gb_r_zieleinkaufspreis.ResumeLayout(false);
            this.gb_r_zieleinkaufspreis.PerformLayout();
            this.gb_r_nettolisteneinkaufspreis.ResumeLayout(false);
            this.gb_r_nettolisteneinkaufspreis.PerformLayout();
            this.gb_d_zieleinkaufspreis.ResumeLayout(false);
            this.gb_d_zieleinkaufspreis.PerformLayout();
            this.gb_d_bareinkaufspreis.ResumeLayout(false);
            this.gb_d_bareinkaufspreis.PerformLayout();
            this.gb_d_einstandspreis.ResumeLayout(false);
            this.gb_d_einstandspreis.PerformLayout();
            this.gb_d_selbstkostenpreis.ResumeLayout(false);
            this.gb_d_selbstkostenpreis.PerformLayout();
            this.gb_gewinn.ResumeLayout(false);
            this.gb_gewinn.PerformLayout();
            this.gb_d_barverkaufspreis.ResumeLayout(false);
            this.gb_d_barverkaufspreis.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.gb_d_zielverkaufspreis.ResumeLayout(false);
            this.gb_d_zielverkaufspreis.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.gb_d_nettolistenverkaufspreis.ResumeLayout(false);
            this.gb_d_nettolistenverkaufspreis.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox tb_nettolisteneinkaufspreis;
        private System.Windows.Forms.Label lbl_nettolisteneinkaufspreis;
        private System.Windows.Forms.Label lbl_lieferantenrabattsatz;
        private System.Windows.Forms.TextBox tb_lieferantenrabattsatz;
        private System.Windows.Forms.Label lbl_lieferantenrabatt;
        private System.Windows.Forms.Label lbl_zieleinkaufspreis;
        private System.Windows.Forms.GroupBox gb_zieleinkaufspreis;
        private System.Windows.Forms.TextBox tb_zieleinkaufspreis;
        private System.Windows.Forms.Button btn_vorwaertskalkulation;
        private System.Windows.Forms.Label lbl_vh_0;
        private System.Windows.Forms.GroupBox gb_bareinkaufspreis;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_zieleinkaufspreis_2;
        private System.Windows.Forms.TextBox tb_lieferskontosatz;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_lieferskontosatz;
        private System.Windows.Forms.Label lbl_bareinkaufspreis;
        private System.Windows.Forms.TextBox tb_bareinkaufspreis;
        private System.Windows.Forms.GroupBox gb_einstandspreis;
        private System.Windows.Forms.Label lbl_absolut;
        private System.Windows.Forms.TextBox tb_bareinkaufspreis_2;
        private System.Windows.Forms.Label lbl_bareinkaufspreis_2;
        private System.Windows.Forms.Label lbl_bezugskosten;
        private System.Windows.Forms.Label lbl_einstandspreis;
        private System.Windows.Forms.TextBox tb_einstandspreis;
        private System.Windows.Forms.TextBox tb_lieferantenrabatt;
        private System.Windows.Forms.TextBox tb_bezugskosten;
        private System.Windows.Forms.TextBox tb_lieferskonto;
        private System.Windows.Forms.GroupBox gb_barverkaufspreis;
        private System.Windows.Forms.TextBox tb_gewinn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_selbstkostenpreis_2;
        private System.Windows.Forms.TextBox tb_gewinnsatz;
        private System.Windows.Forms.Label lbl_gewinn;
        private System.Windows.Forms.Label lbl_selbstkostenpreis_2;
        private System.Windows.Forms.Label lbl_gewinnsatz;
        private System.Windows.Forms.Label lbl_barverkaufspreis;
        private System.Windows.Forms.TextBox tb_barverkaufspreis;
        private System.Windows.Forms.GroupBox gb_selbstkostenpreis;
        private System.Windows.Forms.TextBox tb_handlungskosten;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_einstandspreis_2;
        private System.Windows.Forms.TextBox tb_handlungskostensatz;
        private System.Windows.Forms.Label lbl_handlungskosten;
        private System.Windows.Forms.Label lbl_einstandspreis_2;
        private System.Windows.Forms.Label lbl_handlungskostensatz;
        private System.Windows.Forms.Label lbl_selbstkostenpreis;
        private System.Windows.Forms.TextBox tb_selbstkostenpreis;
        private System.Windows.Forms.GroupBox gb_zielverkaufspreis;
        private System.Windows.Forms.TextBox tb_kundenskonto;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_barverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_kundenskontosatz;
        private System.Windows.Forms.Label lbl_kundenskonto;
        private System.Windows.Forms.Label lbl_barverkaufspreis_2;
        private System.Windows.Forms.Label lbl_kundenskontosatz;
        private System.Windows.Forms.Label lbl_zielverkaufspreis;
        private System.Windows.Forms.TextBox tb_zielverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox gb_nettolistenverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox tb_kundenrabatt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tb_zielverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_kundenrabattsatz;
        private System.Windows.Forms.Label lbl_kundenrabatt;
        private System.Windows.Forms.Label lbl_zielverkaufspreis_2;
        private System.Windows.Forms.Label lbl_kundenrabattsatz;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tb_nettolistenverkaufspreis;
        private System.Windows.Forms.GroupBox gb_bruttoverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox tb_umsatzsteuer;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tb_nettolistenverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_umsatzsteuersatz;
        private System.Windows.Forms.Label lbl_umsatzsteuer;
        private System.Windows.Forms.Label lbl_nettolistenverkaufspreis_2;
        private System.Windows.Forms.Label lbl_umsatzsteuersatz;
        private System.Windows.Forms.Label lbl_bruttoverkaufspreis;
        private System.Windows.Forms.TextBox tb_bruttoverkaufspreis;
        private System.Windows.Forms.GroupBox gb_r_nettolistenverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox tb_r_umsatzsteuer;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox tb_r_nettolistenverkaufspreis;
        private System.Windows.Forms.TextBox tb_r_umsatzsteuersatz;
        private System.Windows.Forms.Label lbl_r_umsatzsteuer;
        private System.Windows.Forms.Label lbl_r_nettolistenverkaufspreis;
        private System.Windows.Forms.Label lbl_r_umsatzsteuersatz;
        private System.Windows.Forms.Label lbl_r_bruttoverkaufspreis;
        private System.Windows.Forms.TextBox tb_r_bruttoverkaufspreis;
        private System.Windows.Forms.Button btn_rueckwaertskalkulation;
        private System.Windows.Forms.GroupBox gb_r_zielverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox tb_r_kundenrabatt;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox tb_r_zielverkaufspreis;
        private System.Windows.Forms.TextBox tb_r_kundenrabattsatz;
        private System.Windows.Forms.Label lbl_r_kundenrabatt;
        private System.Windows.Forms.Label lbl_r_zielverkaufspreis;
        private System.Windows.Forms.Label lbl_r_kundenrabattsatz;
        private System.Windows.Forms.Label lbl_r_nettolistenverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_nettolistenverkaufspreis_2;
        private System.Windows.Forms.GroupBox gb_r_barverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox tb_r_kundenskonto;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox tb_r_barverkaufspreis;
        private System.Windows.Forms.TextBox tb_r_kundenskontosatz;
        private System.Windows.Forms.Label lbl_r_kundenskonto;
        private System.Windows.Forms.Label lbl_r_barverkaufspreis;
        private System.Windows.Forms.Label lbl_r_kundenskontosatz;
        private System.Windows.Forms.Label lbl_r_zielverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_zielverkaufspreis_2;
        private System.Windows.Forms.GroupBox gb_r_selbstkostenpreis;
        private System.Windows.Forms.TextBox tb_r_gewinn;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox tb_r_barverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_gewinnsatz;
        private System.Windows.Forms.Label lbl_r_gewinn;
        private System.Windows.Forms.Label lbl_r_selbstkostenpreis;
        private System.Windows.Forms.Label lbl_r_gewinnsatz;
        private System.Windows.Forms.Label lbl_r_barverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_selbstkostenpreis;
        private System.Windows.Forms.GroupBox gb_r_einstandspreis;
        private System.Windows.Forms.TextBox tb_r_handlungskosten;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox tb_r_selbstkostenpreis_2;
        private System.Windows.Forms.TextBox tb_r_handlungskostensatz;
        private System.Windows.Forms.Label lbl_r_handlungskosten;
        private System.Windows.Forms.Label lbl_r_selbstkostenpreis_2;
        private System.Windows.Forms.Label lbl_r_einstandspreis;
        private System.Windows.Forms.Label lbl_r_handlungskostensatz;
        private System.Windows.Forms.TextBox tb_r_einstandspreis;
        private System.Windows.Forms.GroupBox gb_r_bareinkaufspreis;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox tb_r_einstandspreis_2;
        private System.Windows.Forms.TextBox tb_r_bezugskosten;
        private System.Windows.Forms.Label lbl_r_einstandspreis_2;
        private System.Windows.Forms.Label lbl_r_bareinkaufspreis;
        private System.Windows.Forms.Label lbl_r_bezugskosten;
        private System.Windows.Forms.TextBox tb_r_bareinkaufspreis;
        private System.Windows.Forms.GroupBox gb_r_zieleinkaufspreis;
        private System.Windows.Forms.TextBox tb_r_lieferskonto;
        private System.Windows.Forms.TextBox tb_r_bareinkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_lieferskontosatz;
        private System.Windows.Forms.Label lbl_r_lieferskonto;
        private System.Windows.Forms.Label lbl_r_bareinkaufspreis_2;
        private System.Windows.Forms.Label lbl_r_zieleinkaufspreis;
        private System.Windows.Forms.Label lbl_r_lieferskontosatz;
        private System.Windows.Forms.TextBox tb_r_zieleinkaufspreis;
        private System.Windows.Forms.GroupBox gb_r_nettolisteneinkaufspreis;
        private System.Windows.Forms.TextBox tb_r_lieferantenrabatt;
        private System.Windows.Forms.TextBox tb_r_zieleinkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_lieferantenrabattsatz;
        private System.Windows.Forms.Label lbl_r_lieferantenrabatt;
        private System.Windows.Forms.Label lbl_r_nettolisteneinkaufspreis;
        private System.Windows.Forms.Label lbl_r_lieferantenrabattsatz;
        private System.Windows.Forms.Label lbl_r_zieleinkaufspreis_2;
        private System.Windows.Forms.TextBox tb_r_nettolisteneinkaufspreis;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox gb_d_zieleinkaufspreis;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox tb_d_lieferantenrabatt;
        private System.Windows.Forms.TextBox tb_d_nettolisteneinkaufspreis;
        private System.Windows.Forms.TextBox tb_d_lieferantenrabattsatz;
        private System.Windows.Forms.Label lbl_d_lieferantenrabatt;
        private System.Windows.Forms.Label lbl_d_nettolisteneinkaufspreis;
        private System.Windows.Forms.Label lbl_d_lieferantenrabattsatz;
        private System.Windows.Forms.Label lbl_d_zieleinkaufspreis;
        private System.Windows.Forms.TextBox tb_d_zieleinkaufspreis;
        private System.Windows.Forms.GroupBox gb_d_bareinkaufspreis;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox tb_d_lieferskonto;
        private System.Windows.Forms.TextBox tb_d_zieleinkaufspreis_2;
        private System.Windows.Forms.TextBox tb_d_lieferskontosatz;
        private System.Windows.Forms.Label lbl_d_lieferskonto;
        private System.Windows.Forms.Label lbl_d_zieleinkaufspreis_2;
        private System.Windows.Forms.Label lbl_d_lieferskontosatz;
        private System.Windows.Forms.Label lbl_d_bareinkaufspreis;
        private System.Windows.Forms.TextBox tb_d_bareinkaufspreis;
        private System.Windows.Forms.GroupBox gb_d_einstandspreis;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox tb_d_bareinkaufspreis_2;
        private System.Windows.Forms.TextBox tb_d_bezugskosten;
        private System.Windows.Forms.Label lbl_d_bareinkaufspreis_2;
        private System.Windows.Forms.Label lbl_d_bezugskosten;
        private System.Windows.Forms.Label lbl_d_einstandspreis;
        private System.Windows.Forms.TextBox tb_d_einstandspreis;
        private System.Windows.Forms.GroupBox gb_d_selbstkostenpreis;
        private System.Windows.Forms.TextBox tb_d_handlungskosten;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox tb_d_einstandspreis_2;
        private System.Windows.Forms.TextBox tb_d_handlungskostensatz;
        private System.Windows.Forms.Label lbl_d_handlungskosten;
        private System.Windows.Forms.Label lbl_d_einstandspreis_2;
        private System.Windows.Forms.Label lbl_d_handlungskostensatz;
        private System.Windows.Forms.Label lbl_d_selbstkostenpreis;
        private System.Windows.Forms.TextBox tb_d_selbstkostenpreis;
        private System.Windows.Forms.GroupBox gb_gewinn;
        private System.Windows.Forms.TextBox tb_d_gewinnsatz;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox tb_d_barverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_d_selbstkostenpreis_2;
        private System.Windows.Forms.Label lbl_d_selbstkostenpreis_2;
        private System.Windows.Forms.Label lbl_d_barverkaufspreis_2;
        private System.Windows.Forms.Label lbl_d_gewinnsatz;
        private System.Windows.Forms.Label lbl_d_gewinn;
        private System.Windows.Forms.TextBox tb_d_gewinn;
        private System.Windows.Forms.GroupBox gb_d_barverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox tb_d_kundenskonto;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox tb_d_barverkaufspreis;
        private System.Windows.Forms.TextBox tb_d_kundenskontosatz;
        private System.Windows.Forms.Label lbl_d_kundenskonto;
        private System.Windows.Forms.Label lbl_d_barverkaufspreis;
        private System.Windows.Forms.Label lbl_d_kundenskontosatz;
        private System.Windows.Forms.Label lbl_d_zielverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_d_zielverkaufspreis_2;
        private System.Windows.Forms.GroupBox gb_d_zielverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox tb_d_kundenrabatt;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox tb_d_zielverkaufspreis;
        private System.Windows.Forms.TextBox tb_d_kundenrabattsatz;
        private System.Windows.Forms.Label lbl_d_kundenrabatt;
        private System.Windows.Forms.Label lbl_d_zielverkaufspreis;
        private System.Windows.Forms.Label lbl_d_kundenrabattsatz;
        private System.Windows.Forms.Label lbl_d_nettolistenverkaufspreis_2;
        private System.Windows.Forms.TextBox tb_d_nettolistenverkaufspreis_2;
        private System.Windows.Forms.GroupBox gb_d_nettolistenverkaufspreis;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox tb_d_umsatzsteuer;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox tb_d_nettolistenverkaufspreis;
        private System.Windows.Forms.TextBox tb_d_umsatzsteuersatz;
        private System.Windows.Forms.Label lbl_d_umsatzsteuer;
        private System.Windows.Forms.Label lbl_d_nettolistenverkaufspreis;
        private System.Windows.Forms.Label lbl_d_umsatzsteuersatz;
        private System.Windows.Forms.Label lbl_d_bruttoverkaufspreis;
        private System.Windows.Forms.TextBox tb_d_bruttoverkaufspreis;
        private System.Windows.Forms.Button btn_differenzkalkulation;
    }
}

